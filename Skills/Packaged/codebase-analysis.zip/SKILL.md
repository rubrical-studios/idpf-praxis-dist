---
name: codebase-analysis
description: Analyze existing codebases to extract structure, tech stack, and patterns
version: "0.42.2"
license: Complete terms in LICENSE.txt
---

# Skill: codebase-analysis

**Purpose:** Analyze existing codebases to extract structure, tech stack, and patterns
**Audience:** Used by /create-prd extract, /charter extraction, and codebase exploration
**Load with:** Anti-Hallucination-Rules-for-PRD-Work.md (for PRD/charter work)

---

## Overview

The `codebase-analysis` skill provides shared analysis capabilities for understanding existing codebases. It extracts structural information, detects technology stacks, parses tests for features, and identifies architecture patterns.

**Use Case:** Foundation for `/create-prd extract`, `/charter` extraction mode, and general codebase understanding.

**Critical:** All analysis output must be traceable to code evidence. Never invent details not supported by actual files, tests, or code patterns. Mark all inferences with confidence levels.

---

## When to Use

- `/create-prd extract` - Analyzing codebase for PRD generation
- `/charter` extraction mode - Analyzing codebase for charter generation
- `/charter refresh` - Re-analyzing codebase for charter updates
- General codebase exploration and understanding

---

## Analysis Capabilities

### 1. Tech Stack Detection

Detect languages, frameworks, and dependencies from project files.

**Primary Sources:**

| File Pattern | Detects | Example |
|--------------|---------|---------|
| `package.json` | Node.js, npm deps | `"express": "4.x"` → Express.js |
| `requirements.txt`, `pyproject.toml` | Python, pip deps | `flask==2.0` → Flask |
| `go.mod` | Go, modules | `require github.com/gin-gonic/gin` → Gin |
| `Gemfile` | Ruby, gems | `gem 'rails'` → Ruby on Rails |
| `pom.xml`, `build.gradle` | Java, Maven/Gradle | Spring, Hibernate |
| `Cargo.toml` | Rust, crates | `tokio`, `actix-web` |
| `.csproj`, `packages.config` | .NET, NuGet | ASP.NET, Entity Framework |

**Secondary Sources:**

| File Pattern | Detects |
|--------------|---------|
| `Dockerfile` | Containerization, base images |
| `.github/workflows/*.yml` | CI/CD, GitHub Actions |
| `docker-compose.yml` | Service architecture |
| `*.config`, `*.yaml` | Configuration patterns |

**Output:** Technology summary with confidence levels.

### 2. Architecture Inference

Infer system architecture from code organization and patterns.

**Directory Pattern Detection:**

| Pattern | Architecture Style |
|---------|-------------------|
| `src/`, `lib/`, `app/` | Monolith (single-tier) |
| `frontend/`, `backend/`, `api/` | Multi-tier separation |
| `services/*/`, `microservices/` | Microservices |
| `domain/`, `infrastructure/`, `application/` | Clean/Hexagonal |
| `models/`, `views/`, `controllers/` | MVC pattern |
| `components/`, `pages/`, `hooks/` | Frontend component-based |

**Layer Detection:**

| Layer | Indicators |
|-------|------------|
| Presentation | `views/`, `templates/`, `components/`, `pages/` |
| API | `routes/`, `api/`, `endpoints/`, `handlers/` |
| Business Logic | `services/`, `domain/`, `core/`, `usecases/` |
| Data Access | `repositories/`, `models/`, `db/`, `data/` |
| Infrastructure | `config/`, `infrastructure/`, `utils/` |

**Output:** Architecture style, detected layers, component relationships.

### 3. Test Parsing

Parse test files to extract feature descriptions and coverage.

**Supported Test Frameworks:**

| Framework | File Pattern | Feature Extraction |
|-----------|--------------|-------------------|
| pytest | `test_*.py`, `*_test.py` | Function names, docstrings, parametrize |
| Jest | `*.test.js`, `*.spec.js` | describe/it blocks |
| JUnit | `*Test.java`, `*Tests.java` | @Test methods, @DisplayName |
| RSpec | `*_spec.rb` | describe/context/it blocks |
| Go testing | `*_test.go` | Test* functions |
| xUnit | `*.Tests.cs` | [Fact], [Theory] methods |

**Extraction Pattern:**

```
Test File → Test Suite → Test Case → Feature Description
                                   → Expected Behavior
                                   → Edge Cases
```

**Output:** Feature list with test evidence, coverage assessment.

### 4. NFR Detection

Detect non-functional requirements from code patterns.

**Security Patterns:**

| Pattern | NFR Inference |
|---------|---------------|
| `bcrypt`, `argon2`, password hashing | Password security required |
| JWT, OAuth, session management | Authentication required |
| CORS configuration | Cross-origin access control |
| Input validation, sanitization | Input security required |
| Rate limiting middleware | Rate limiting required |

**Performance Patterns:**

| Pattern | NFR Inference |
|---------|---------------|
| Redis, Memcached usage | Caching required |
| Connection pooling | Database performance |
| Async/await, promises | Non-blocking I/O |
| CDN configuration | Content delivery |
| Load balancer config | Horizontal scaling |

**Reliability Patterns:**

| Pattern | NFR Inference |
|---------|---------------|
| Retry logic, circuit breakers | Fault tolerance |
| Health check endpoints | Monitoring required |
| Logging (structured) | Observability |
| Error handling patterns | Error recovery |
| Transaction management | Data consistency |

**Output:** NFR list with code evidence and confidence levels.

---

## Usage

### Load for PRD/Charter Work

```
1. Load: Skills/codebase-analysis/SKILL.md
2. Load: Assistant/Anti-Hallucination-Rules-for-PRD-Work.md
3. Run analysis commands as needed
```

### Analysis Commands

| Command | Purpose | Output |
|---------|---------|--------|
| `Analyze-Tech-Stack` | Detect languages, frameworks, dependencies | Tech-Stack summary |
| `Analyze-Architecture` | Infer structure, layers, patterns | Architecture summary |
| `Analyze-Tests` | Parse tests for features | Feature list with evidence |
| `Analyze-NFRs` | Detect NFRs from patterns | NFR list with evidence |
| `Full-Analysis` | Run all analysis commands | Complete codebase summary |

---

## Confidence Levels

All analysis output must include confidence assessment:

| Level | Meaning | Action |
|-------|---------|--------|
| **High** | Direct code evidence (test file, config value) | Use directly |
| **Medium** | Inferred from patterns (directory structure, naming) | Flag for validation |
| **Low** | Weak signals, assumptions | Require user confirmation |

**Format:**

```markdown
**Feature:** User Registration
**Confidence:** High
**Evidence:**
- test_user_registration.py (15 test cases)
- POST /api/register endpoint
- User model in models/user.py
```

---

## Integration Points

| Consumer | Uses For |
|----------|----------|
| `/create-prd extract` | PRD generation from codebase |
| `/charter` extraction | Charter generation from codebase |
| `/charter refresh` | Charter updates from code changes |
| Anti-pattern analysis | Code quality assessment |

---

## Resources

| Resource | Purpose |
|----------|---------|
| `resources/test-parsing-guide.md` | Detailed test parsing patterns |
| `resources/nfr-detection-guide.md` | NFR detection patterns by category |
| `resources/tech-stack-detection.md` | Tech stack detection patterns |
| `resources/architecture-inference.md` | Architecture inference patterns |

---

## Anti-Hallucination Rules

When performing codebase analysis:

1. **Only report what exists** - Don't invent features not found in code
2. **Cite evidence** - Every finding must reference specific files/patterns
3. **Use confidence levels** - Be honest about inference certainty
4. **Flag gaps** - Note what's missing or unclear
5. **Validate with user** - Medium/Low confidence items need confirmation

---

**End of Skill Document**
