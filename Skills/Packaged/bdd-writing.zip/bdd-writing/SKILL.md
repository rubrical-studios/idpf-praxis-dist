---
name: bdd-writing
description: Guide developers on writing BDD specifications using Gherkin syntax, feature files, and step definitions
version: "0.34.1"
license: Complete terms in LICENSE.txt
---

# BDD Writing

This Skill provides guidance for writing Behavior-Driven Development (BDD) specifications using Gherkin syntax. It covers feature files, step definitions, and integration with TDD workflows.

## When to Use This Skill

Invoke this Skill when:
- Writing acceptance criteria as executable specifications
- Creating feature files for new functionality
- Defining step definitions for scenarios
- Organizing BDD test suites
- Integrating BDD with TDD workflow
- Questions about Gherkin syntax
- Need tool selection guidance (Cucumber, pytest-bdd, etc.)

## Prerequisites

- Understanding of testing concepts
- Familiarity with TDD (recommended)
- Knowledge of at least one programming language

## What is BDD?

Behavior-Driven Development bridges the gap between technical and non-technical stakeholders by using natural language specifications that are also executable tests.

**Key Principle:** Describe behavior in terms users understand, then automate those descriptions as tests.

```
Traditional: "Test that login validates credentials"
BDD:         "Given a registered user, When they enter valid credentials, Then they see the dashboard"
```

## Gherkin Syntax

### Core Keywords

| Keyword | Purpose | Example |
|---------|---------|---------|
| **Feature** | Groups related scenarios | `Feature: User Authentication` |
| **Scenario** | Single test case | `Scenario: Successful login` |
| **Given** | Preconditions/context | `Given a registered user exists` |
| **When** | Action/event | `When the user submits credentials` |
| **Then** | Expected outcome | `Then they see the dashboard` |
| **And** | Continue previous step type | `And they see a welcome message` |
| **But** | Negative continuation | `But they don't see admin menu` |
| **Background** | Shared setup for all scenarios | Runs before each scenario |
| **Scenario Outline** | Parameterized scenarios | Data-driven tests |
| **Examples** | Data table for outlines | Test data variations |

### Basic Feature File Structure

```gherkin
Feature: User Authentication
  As a registered user
  I want to log into the system
  So that I can access my account

  Background:
    Given the login page is displayed

  Scenario: Successful login with valid credentials
    Given a user "alice" exists with password "secret123"
    When the user enters username "alice"
    And the user enters password "secret123"
    And the user clicks the login button
    Then the user sees the dashboard
    And the user sees "Welcome, alice"

  Scenario: Failed login with wrong password
    Given a user "alice" exists with password "secret123"
    When the user enters username "alice"
    And the user enters password "wrongpassword"
    And the user clicks the login button
    Then the user sees an error message "Invalid credentials"
    But the user remains on the login page
```

### Scenario Outline (Parameterized Tests)

```gherkin
Scenario Outline: Login with various credentials
  Given a user "<username>" exists with password "<password>"
  When the user attempts to login with "<input_user>" and "<input_pass>"
  Then the result is "<outcome>"

  Examples:
    | username | password  | input_user | input_pass | outcome |
    | alice    | secret123 | alice      | secret123  | success |
    | alice    | secret123 | alice      | wrong      | failure |
    | alice    | secret123 | bob        | secret123  | failure |
```

### Data Tables

```gherkin
Scenario: Create multiple users
  Given the following users exist:
    | username | email            | role  |
    | alice    | alice@example.com| admin |
    | bob      | bob@example.com  | user  |
    | carol    | carol@example.com| user  |
  When I view the user list
  Then I see 3 users
```

### Doc Strings (Multi-line Text)

```gherkin
Scenario: Create a blog post
  Given I am logged in as an author
  When I create a post with content:
    """
    # Welcome to My Blog

    This is my first post.
    It has multiple lines.
    """
  Then the post is published
```

## Step Definitions

### Pattern: Match Steps to Code

Step definitions connect Gherkin steps to executable code.

**JavaScript (Cucumber.js):**
```javascript
const { Given, When, Then } = require('@cucumber/cucumber');

Given('a user {string} exists with password {string}', async (username, password) => {
  await createUser(username, password);
});

When('the user enters username {string}', async (username) => {
  await enterUsername(username);
});

Then('the user sees the dashboard', async () => {
  await expect(page).toHaveURL('/dashboard');
});
```

**Python (pytest-bdd):**
```python
from pytest_bdd import given, when, then, parsers

@given(parsers.parse('a user "{username}" exists with password "{password}"'))
def create_user(username, password):
    User.create(username=username, password=password)

@when(parsers.parse('the user enters username "{username}"'))
def enter_username(username, login_page):
    login_page.enter_username(username)

@then('the user sees the dashboard')
def verify_dashboard(page):
    assert page.url == '/dashboard'
```

**Java (Cucumber):**
```java
public class LoginSteps {
    @Given("a user {string} exists with password {string}")
    public void createUser(String username, String password) {
        userService.create(username, password);
    }

    @When("the user enters username {string}")
    public void enterUsername(String username) {
        loginPage.enterUsername(username);
    }

    @Then("the user sees the dashboard")
    public void verifyDashboard() {
        assertThat(driver.getCurrentUrl()).contains("/dashboard");
    }
}
```

### Step Definition Best Practices

**1. Keep Steps Reusable**
```gherkin
# Good - Reusable
Given a user "alice" exists
Given a user "bob" exists

# Poor - Too specific
Given alice the admin user exists in the system
Given bob the regular user exists in the database
```

**2. Use Parameters**
```javascript
// Good - Single definition handles multiple cases
Given('a user {string} with role {string}', (name, role) => { ... });

// Poor - Duplicate definitions
Given('an admin user alice', () => { ... });
Given('a regular user bob', () => { ... });
```

**3. Declarative Over Imperative**
```gherkin
# Good - Declarative (what, not how)
Given the user is logged in

# Poor - Imperative (too detailed)
Given the user opens the login page
And the user enters username "alice"
And the user enters password "secret"
And the user clicks login
And the user waits for redirect
```

## Best Practices

### Feature Organization

```
features/
├── authentication/
│   ├── login.feature
│   ├── logout.feature
│   └── password_reset.feature
├── orders/
│   ├── create_order.feature
│   ├── cancel_order.feature
│   └── order_history.feature
└── support/
    ├── step_definitions/
    │   ├── auth_steps.js
    │   └── order_steps.js
    └── hooks.js
```

### Writing Good Scenarios

| Do | Don't |
|----|-------|
| One behavior per scenario | Multiple behaviors per scenario |
| Use business language | Use technical jargon |
| Keep scenarios short (3-7 steps) | Write long scenarios (10+ steps) |
| Make scenarios independent | Create dependencies between scenarios |
| Focus on behavior | Focus on UI mechanics |

### Naming Conventions

**Feature names:** Describe the capability
```gherkin
Feature: Shopping Cart Management
Feature: User Registration
Feature: Payment Processing
```

**Scenario names:** Describe the specific behavior
```gherkin
Scenario: Add single item to empty cart
Scenario: Remove last item empties the cart
Scenario: Apply valid discount code reduces total
```

## Anti-Patterns to Avoid

### 1. UI-Focused Steps
```gherkin
# Poor - Tests UI mechanics
When I click the button with id "submit-btn"
And I wait for the spinner to disappear
And I scroll to the bottom of the page

# Good - Tests behavior
When I submit my order
```

### 2. Too Many Steps
```gherkin
# Poor - Too long
Scenario: Complete checkout process
  Given I am logged in
  And I have items in my cart
  And I go to checkout
  And I enter shipping address
  And I select shipping method
  And I enter payment details
  And I review my order
  And I confirm my order
  And I wait for confirmation
  Then I see order confirmation
  And I receive confirmation email
  And inventory is updated
  And payment is processed
```

Split into focused scenarios:
```gherkin
Scenario: Enter shipping information
Scenario: Select shipping method
Scenario: Process payment
Scenario: Confirm order
```

### 3. Coupled Steps
```gherkin
# Poor - Steps depend on each other
Given I set the username variable to "alice"
When I use the username variable to login

# Good - Self-contained
When the user "alice" logs in
```

### 4. Inconsistent Language
```gherkin
# Poor - Inconsistent terminology
Given a customer is logged in
When the user adds an item
Then the client sees the cart

# Good - Consistent
Given a user is logged in
When the user adds an item
Then the user sees the cart
```

## BDD + TDD Integration (Double Loop)

BDD and TDD work together in a "double loop" pattern:

```
┌─────────────────────────────────────────────────────────┐
│  OUTER LOOP: BDD (Acceptance Tests)                     │
│                                                         │
│  1. Write failing acceptance scenario                   │
│                                                         │
│  ┌─────────────────────────────────────────────────┐    │
│  │  INNER LOOP: TDD (Unit Tests)                   │    │
│  │                                                 │    │
│  │  2. RED: Write failing unit test                │    │
│  │  3. GREEN: Write minimal code to pass           │    │
│  │  4. REFACTOR: Improve code quality              │    │
│  │  5. Repeat until feature complete               │    │
│  │                                                 │    │
│  └─────────────────────────────────────────────────┘    │
│                                                         │
│  6. Acceptance scenario passes                          │
│  7. Move to next scenario                               │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

**Workflow:**
1. Write a BDD scenario (fails - feature doesn't exist)
2. Write unit tests for required components (TDD inner loop)
3. Implement until scenario passes
4. Refactor
5. Next scenario

## Tool Selection Guide

| Tool | Language | Best For |
|------|----------|----------|
| **Cucumber** | JS, Java, Ruby | Most popular, multi-language |
| **pytest-bdd** | Python | Python projects, pytest integration |
| **SpecFlow** | C#/.NET | .NET ecosystem |
| **Behave** | Python | Python alternative to pytest-bdd |
| **RSpec** | Ruby | Ruby with BDD-style syntax |
| **Karate** | Java | API testing with BDD |

### Quick Selection

```
Python project?
├── Using pytest? → pytest-bdd
└── Not using pytest? → Behave

JavaScript project? → Cucumber.js

Java project?
├── API testing focus? → Karate
└── General BDD? → Cucumber-JVM

.NET project? → SpecFlow

Ruby project? → Cucumber or RSpec
```

## Resources

See `resources/` directory for:
- `gherkin-syntax.md` - Complete Gherkin reference
- `feature-file-template.md` - Feature file template
- `step-definition-patterns.md` - Step definition examples by language
- `tool-comparison.md` - Detailed tool comparison

## Relationship to Other Skills

**Complements:**
- `test-writing-patterns` - BDD is an alternative test structure (Given-When-Then vs AAA)
- `tdd-red-phase` - BDD scenarios drive the outer TDD loop
- `beginner-testing` - BDD is accessible to beginners

**Used by:**
- IDPF-Agile - BDD for user story validation and acceptance criteria verification

## Expected Outcome

After applying BDD writing patterns:
- Feature files are clear and readable
- Scenarios focus on behavior, not implementation
- Step definitions are reusable and maintainable
- BDD integrates smoothly with TDD workflow
- Stakeholders can understand and contribute to specifications

---

**End of BDD Writing Skill**
