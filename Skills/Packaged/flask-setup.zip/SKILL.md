---
name: flask-setup-for-beginners
description: Set up Python Flask development environment for beginners with step-by-step guidance, virtual environment creation, and troubleshooting
version: "0.42.2"
license: Complete terms in LICENSE.txt
---

# Flask Setup for Beginners

This Skill guides complete beginners through setting up a Flask development environment with detailed explanations and verification steps.

## When to Use This Skill

Invoke this Skill when:
- User wants to build a Flask web application
- User is a beginner and needs Flask environment setup
- User asks "How do I set up Flask?" or "How do I start a Flask project?"
- Project type is determined to be web application using Flask

## Instructions for ASSISTANT

**CRITICAL OUTPUT FORMAT:**

When using this Skill's content, the ASSISTANT must format ALL technical instructions as **Claude Code copy/paste blocks**.

**DO NOT provide manual instructions like:**
- ❌ "Open File Explorer"
- ❌ "Navigate to folder"
- ❌ "Right-click"
- ❌ "Type in terminal"

**ALWAYS format as:**
```
TASK: Set up Flask project

STEP 1: Copy this entire code block (including this line)
STEP 2: Open Claude Code
STEP 3: Paste into Claude Code
STEP 4: Claude Code will execute and report results
STEP 5: Report back: What did Claude Code say?

---

[Instructions for Claude Code to execute:]

Navigate to project directory:
cd [project-location]

Create project folder:
mkdir [project-name]
cd [project-name]

Check Python installed:
python --version

Create virtual environment:
python -m venv venv

[continue with commands...]

Report:
- What results did you see?
```

## Setup Knowledge

The following content provides setup knowledge. ASSISTANT must convert this into Claude Code commands:

### Create Project and Verify Python

**What this does:** Opens a command line interface in your project directory

**Verify:** You should see your project folder path in the terminal

### STEP 3: Create Virtual Environment

**Command:**
```bash
python -m venv venv
```

**What this does:**
- Creates a special Python environment just for this project
- Installs packages separately from your system Python
- Prevents conflicts between different projects

**Why we do this:**
- Keeps project dependencies isolated
- Different projects can use different package versions
- Makes your project portable and reproducible

**Wait time:** 10-30 seconds (creates folder structure)

**Verify:** You should see a new `venv` folder in your project directory

**Common issues:**
- "python: command not found" → Python not installed or not in PATH
  - Install Python from python.org
  - On Windows, check "Add Python to PATH" during installation
- "python3" instead of "python" → Try `python3 -m venv venv`

### STEP 4: Activate Virtual Environment

**Windows PowerShell:**
```bash
venv\Scripts\Activate.ps1
```

**Windows Command Prompt:**
```bash
venv\Scripts\activate.bat
```

**Mac/Linux:**
```bash
source venv/bin/activate
```

**What this does:**
- Switches your terminal to use the virtual environment's Python
- Any packages you install will go into this environment only

**Success indicator:** You'll see `(venv)` appear at the start of your terminal prompt

**Example:**
```
Before: C:\Projects\my-app>
After:  (venv) C:\Projects\my-app>
```

**Common issues:**
- "Execution policy error" (Windows) → Run PowerShell as Administrator:
  ```bash
  Set-ExecutionPolicy -ExecutionPolicy RemoteSigned -Scope CurrentUser
  ```
- Nothing happens → Make sure you're in the project directory
- `(venv)` doesn't appear → Try closing and reopening terminal

### STEP 5: Install Flask

**Command:**
```bash
pip install flask
```

**What this does:**
- Downloads Flask from the Python Package Index (PyPI)
- Installs Flask and its dependencies into your virtual environment
- Makes Flask available for import in your Python code

**Wait time:** 30-60 seconds (downloads and installs)

**You'll see:**
- Progress messages as packages download
- "Successfully installed flask-X.X.X" at the end

**What gets installed:**
- Flask itself
- Werkzeug (web server utilities)
- Jinja2 (template engine)
- Click (command-line interface)
- Other dependencies

**Common issues:**
- "pip: command not found" → Virtual environment not activated (see Step 4)
- Slow installation → Normal if internet is slow
- Permission errors → Make sure virtual environment is activated

### STEP 6: Create app.py File

**Instructions:**
1. Open your favorite text editor (VS Code, Sublime, PyCharm, Notepad++, etc.)
2. Create a new file
3. Save it as `app.py` in your project folder (same level as `venv` folder)

**Recommended editors for beginners:**
- **VS Code**: Free, powerful, good Python support
- **PyCharm Community**: Free, Python-focused
- **Sublime Text**: Fast, simple
- **Notepad++**: Windows, simple

**File location should be:**
```
my-project/
├── venv/           ← Virtual environment folder
└── app.py          ← Your main Flask file (create this)
```

**Don't create app.py inside the venv folder!**

### STEP 7: Verify Installation

**Command 1: Check Python version**
```bash
python --version
```

**Expected output:** `Python 3.8.x` or higher

**Command 2: Check installed packages**
```bash
pip list
```

**Expected output:** You should see Flask (and its dependencies) in the list:
```
Package      Version
------------ -------
click        X.X.X
Flask        X.X.X
Jinja2       X.X.X
Werkzeug     X.X.X
...
```

**Command 3: Test Flask import**
```bash
python -c "import flask; print(flask.__version__)"
```

**Expected output:** Flask version number (e.g., `3.0.0`)

**All checks pass?** You're ready to start coding!

### STEP 8: Report Completion

**Report to the ASSISTANT:**
- "Setup complete! I see (venv) in my terminal and Flask is installed"
- Or if issues: "I got stuck at step X with error: [exact error message]"

## What Happens Next

After successful setup:
1. ASSISTANT will guide you through creating your first Flask route
2. You'll write "Hello World" application
3. You'll start the Flask development server
4. You'll see your first web page in a browser

## Troubleshooting Quick Reference

See `resources/verification-checklist.md` for detailed troubleshooting steps.

**Most common issues:**
1. **Forgot to activate virtual environment** → See Step 4
2. **Python not in PATH** → Reinstall Python with "Add to PATH" checked
3. **Wrong directory** → Use `cd` to navigate to project folder
4. **Permission errors** → Virtual environment not activated
5. **Port/firewall issues** → Will address when running server

## Next Steps

Once setup is complete:
- Create your first Flask route
- Learn about Flask's development server
- Understand the request/response cycle
- Build your first web page

---

**Remember:** Keep the terminal window with `(venv)` open while developing!
