---
name: create-prd
description: Transform proposals into detailed PRD documents using Inception/ context
version: "0.34.1"
license: Complete terms in LICENSE.txt
---

# Skill: create-prd

**Purpose:** Transform proposals into detailed PRD documents using Inception/ context
**Audience:** Developers promoting approved proposals to actionable requirements
**Load with:** Anti-Hallucination-Rules-for-PRD-Work.md

---

## Overview

The `create-prd` skill transforms a proposal document into a detailed Product Requirements Document (PRD). It uses Inception/ artifacts as context to validate scope alignment and generate targeted clarifying questions.

**Key Principle:** Proposals capture the "what and why" at a high level. PRDs add the "how" with user stories, acceptance criteria, and prioritized requirements.

**Replaces:** IDPF-PRD 4-phase workflow (Discovery → Elicitation → Specification → Generation)

---

## When to Use

- Proposal approved and ready for implementation planning
- Need detailed requirements before Create-Backlog
- Want to validate proposal fits current charter scope
- Need user stories and acceptance criteria from high-level idea

---

## Skill Commands

| Command | Purpose |
|---------|---------|
| `/create-prd` | Interactive mode selection |
| `/create-prd <proposal-path>` | Transform proposal into PRD |
| `/create-prd extract` | Extract PRD from codebase |
| `/create-prd extract <directory>` | Extract PRD from specific directory |

**Examples:**
```
/create-prd                         # Prompts for mode selection
/create-prd Proposal/Feature-X.md   # Promote proposal to PRD
/create-prd extract                 # Extract PRD from entire codebase
/create-prd extract src/            # Extract PRD from src/ directory
```

**Interactive Mode:**
```
How would you like to create the PRD?

1. From a proposal document
2. From existing code (extraction)

> [user selects]
```

---

## Process Flow

### Phase 1: Load Context

Load these files to establish context:

| File | Purpose | Required |
|------|---------|----------|
| `<proposal-path>` | The proposal to promote | Yes |
| `CHARTER.md` | Project vision and current focus | If exists |
| `Inception/Scope-Boundaries.md` | In-scope/out-of-scope items | If exists |
| `Inception/Constraints.md` | Technical/business constraints | If exists |
| `Inception/Architecture.md` | System architecture | If exists |
| `Inception/Charter-Details.md` | Full charter context | On-demand |

**If no Inception/ artifacts exist:**
- Proceed with proposal analysis only
- Flag that scope validation is limited
- Recommend running `/charter` first

---

### Phase 2: Validate Against Charter

Compare proposal against current charter scope:

| Check | Action if Misaligned |
|-------|---------------------|
| Fits in-scope items | Continue |
| Outside current scope | Ask: "This isn't in current scope. Expand scope?" |
| Conflicts with constraints | Flag conflict, ask for resolution |
| Depends on out-of-scope work | Identify dependencies |

**Conversational Resolution:**
```
"This proposal adds [X], but current scope focuses on [Y].

Options:
1. Expand charter scope to include this
2. Defer to future release
3. Proceed anyway (creates charter drift)"
```

---

### Phase 3: Analyze Proposal Gaps

Parse the proposal to identify what's present and what's missing:

| Element | How to Detect | Gap Action |
|---------|---------------|------------|
| Problem statement | "Problem:", "Issue:", first paragraph | Ask if missing |
| Proposed solution | "Solution:", "Approach:", section headers | Ask if missing |
| User stories | "As a...", "User can..." | Generate questions |
| Acceptance criteria | "- [ ]", "Done when", "Acceptance:" | Generate questions |
| Technical requirements | "Must support", "Requires", tech terms | Infer from constraints |
| Priority | "P0-P3", "High/Medium/Low" | Ask if missing |
| Scope boundaries | "Out of scope", "Not included" | Generate from context |

**Gap Summary Example:**
```
Proposal Analysis:
✓ Problem statement (clear)
✓ Proposed solution (outline)
✗ User stories (missing - will ask)
✗ Acceptance criteria (missing - will ask)
○ Technical requirements (partially covered)
✗ Priority (missing - will ask)
```

---

### Phase 4: Dynamic Question Generation

Generate questions based on gaps AND project context. Questions are NOT from a static bank—they're tailored to this specific proposal.

**Question Categories:**

| Category | Trigger | Example Questions |
|----------|---------|-------------------|
| Users | No user stories | "Who are the primary users of [feature]?" |
| Workflow | Vague solution | "What's the main workflow for [feature]?" |
| Done criteria | No acceptance criteria | "What does 'done' look like for this?" |
| Constraints | Architecture implications | "Any constraints from current architecture?" |
| Priority | No priority stated | "Priority relative to other work?" |
| Edge cases | Complex feature | "What edge cases should we handle?" |
| Dependencies | Cross-cutting concern | "Does this depend on other work?" |

**Question Generation Rules:**

1. **Context-aware:** Reference specific details from proposal
2. **Minimal:** Only ask what's truly missing
3. **Specific:** "Who uses the bulk import feature?" not "Who are users?"
4. **Actionable:** Each answer directly becomes PRD content

**Asking Questions:**
- Present 3-5 questions at a time
- Use conversational tone
- Allow "skip" or "not sure" responses
- Adapt follow-ups based on answers

---

### Phase 4.5: Story Transformation

Transform proposal requirements/features into proper Agile user stories. This phase ensures the PRD follows user-focused format rather than waterfall-style numbered requirements.

**Transformation Process:**

For each proposal requirement or feature:

```
1. Identify the USER (who benefits?)
2. Identify the CAPABILITY (what can they do?)
3. Identify the BENEFIT (why does it matter?)
4. Transform into story format
```

**Anti-Pattern Detection:**

Flag implementation-level details that don't belong in user stories:

| Anti-Pattern | Indicators | Action |
|--------------|------------|--------|
| File operations | "rename file", "move to", file paths | Flag as Technical Note |
| Internal changes | "refactor", "update config", "script changes" | Flag as Technical Note |
| Code-level details | function names, class names, module references | Flag as Technical Note |
| System internals | "installer", "deployment", "registry" | Flag as Technical Note |

**When Anti-Pattern Detected:**

```
⚠ This looks like an implementation detail:
   "[requirement text]"

Implementation details go in Technical Notes, not user stories.

What user problem does this solve?
> [user input]

Transforming to user story...
```

**Transformation Example:**

Before (Implementation-focused):
```
REQ-001: Rename /open-release to /create-branch
- AC-001.1: .claude/commands/open-release.md renamed to create-branch.md
- AC-001.2: Command accepts any [prefix]/[identifier] pattern
```

After (User-focused):
```
### Story: Create Tracked Branches for Any Purpose

**As a** framework maintainer
**I want** a unified command to create tracked branches with any prefix
**So that** I have one mental model instead of separate release/patch/feature workflows

**Acceptance Criteria:**
- [ ] /create-branch release/v0.23.0 creates release tracker
- [ ] /create-branch feature/dark-mode works with arbitrary prefixes
- [ ] Tracker issue created with "Branch:" title prefix

> **Technical Note:** Implements file rename from open-release.md to create-branch.md
```

**Transformation Questions:**

If unable to automatically transform, ask:

| Question | Purpose |
|----------|---------|
| "Who uses this feature?" | Identify the user persona |
| "What can they do with it?" | Identify the capability |
| "Why does that matter to them?" | Identify the benefit |
| "What proves it's working?" | Generate acceptance criteria |

---

### Phase 5: Priority Validation

Before generating the PRD, validate priority distribution to ensure meaningful prioritization.

**Validation Rules:**

| Priority | Required Distribution |
|----------|----------------------|
| P0 (Must Have) | ≤40% of stories |
| P1 (Should Have) | 30-40% of stories |
| P2 (Could Have) | ≥20% of stories |

**Small PRD Exemption:**

PRDs with fewer than 6 stories are exempt from distribution validation. Percentages don't map cleanly to small counts.

**Validation Process:**

```
1. Count total stories
2. If < 6 stories → Skip validation, proceed to generation
3. Calculate distribution percentages
4. If invalid → Trigger prioritization questions
5. If valid → Proceed to generation
```

**When Distribution Invalid:**

```
⚠ Priority distribution doesn't reflect trade-offs:
   P0: 80% (should be ≤40%)
   P1: 15% (should be 30-40%)
   P2: 5% (should be ≥20%)

Not everything can be Must Have. Let's prioritize.

If you could only ship 3 of these, which would they be?
1. [Story A]
2. [Story B]
3. [Story C]
...

> [user selects]

Which are nice-to-have but not critical for v1?
> [user selects]

Redistributing priorities...
```

**Prioritization Questions:**

| Question | Purpose |
|----------|---------|
| "If you could only ship 3, which would they be?" | Identify true P0s |
| "Which are nice-to-have but not critical?" | Identify P2s |
| "What's blocked if [story] isn't done?" | Validate P0 dependencies |
| "Could v1 launch without [story]?" | Challenge P0 classification |

---

### Phase 5.5: Diagram Generation (Optional)

Generate UML diagrams as `.drawio.svg` files to enhance PRD communication.

#### 5.5.1 Diagram Type Selection

**Supported Diagram Types:**

| Diagram Type | Default | Purpose |
|--------------|---------|---------|
| **Use Case** | ✅ ON | Actor interactions, feature scope |
| **Activity** | ✅ ON | Workflows, decision points |
| **Class** | ❌ OFF | Domain models, data structures |
| **State Machine** | ❌ OFF | Lifecycle flows, status transitions |
| **Deployment** | ❌ OFF | Infrastructure, system topology |
| **Sequence** | ❌ OFF | Component interactions, API flows |

**Selection Workflow (Hybrid):**

```
Step 1: Select default diagram types for ALL epics
        [x] Use Case
        [x] Activity
        [ ] Class
        [ ] State Machine
        [ ] Deployment
        [ ] Sequence

Step 2: Per-epic confirmation
        Epic: "Branch Management"
        Use these defaults? (yes/customize)
        > customize
        [ ] Use Case (reason: pure technical changes)
        [x] Activity (reason: multi-step workflow)
```

**Assistant Override:** The assistant can intelligently override defaults based on epic context. For example, suggest Class diagram for a data-modeling epic even if Class is OFF by default.

#### 5.5.2 Appropriateness Guidance

Before generating diagrams, evaluate appropriateness using the base matrix and qualifiers.

**Base Matrix:**

| Diagram Type | Appropriate When | Not Appropriate When |
|--------------|------------------|----------------------|
| Use Case | User-facing features, actor interactions | Pure technical/infrastructure changes |
| Activity | Multi-step workflows, decision points | Simple CRUD operations |
| Class | Domain models, data structures, OOP design | Script-only changes, config updates |
| State Machine | Lifecycle flows, status transitions | Simple flag toggles |
| Deployment | Infrastructure, system topology | Single-service changes |
| Sequence | API interactions, multi-component flows | Internal method calls |

**Qualifiers:**

| Qualifier | Check |
|-----------|-------|
| Complexity Threshold | Skip if scope too simple (e.g., 2-step sequence) |
| Epic Size | Small epics (1-2 stories) may not warrant diagrams |
| Integration Scope | Cross-system = more diagrams; internal = fewer |
| Novelty | Greenfield needs more; modifications to documented systems need less |
| Audience | Stakeholder → Use Case, Activity; Developer → Class, Sequence |

**Guidance Logic:**

```
1. Check base matrix (is diagram type fundamentally appropriate?)
2. Check epic size (≥3 stories to warrant diagrams?)
3. Check complexity (enough steps/components to visualize?)
4. Check novelty (new vs. modification to existing?)
5. If 2+ checks fail → advise against with reason
```

**Example Guidance:**

```
Epic: "Config File Rename"
Stories: 2

Assessment:
❌ Epic size: 2 stories (minimum 3 for diagrams)
❌ Complexity: Simple file operations
✓ Base matrix: Activity could work for workflow

Recommendation: Skip diagrams for this epic.
Reason: Too simple—would not add value.
```

#### 5.5.3 Content Generation

Diagrams are **fully generated** with content derived from PRD elements:

| Diagram Type | Content Source |
|--------------|----------------|
| Use Case | Actors from PRD personas and "As a..." clauses |
| Activity | Steps from acceptance criteria and workflow descriptions |
| Sequence | Interactions from documented behavior and Technical Notes |
| Class | Entities from data models mentioned in stories |
| State Machine | States/transitions from acceptance criteria |
| Deployment | Components from Technical Notes and architecture |

**Traceability Requirement:**

Each diagram element MUST trace to a PRD source:

```
Actor: "Framework Maintainer" (Story 1.1, 2.1, 3.1)
Use Case: "Create Tracked Branch" (Story 1.1)
Activity Step: "Validate branch name" (Story 1.1, AC-1)
```

#### 5.5.4 File Format and Location

**Format:** `.drawio.svg` (SVG with embedded draw.io XML)

Benefits:
- Renders as viewable image on GitHub
- Fully editable in draw.io application
- Version control friendly
- Single file for both viewing and editing

**Location:** See Phase 6 for new PRD directory structure.

**Naming Convention:**

| Component | Convention | Example |
|-----------|------------|---------|
| Diagram file | `{type}-{description}.drawio.svg` | `use-case-branch-operations.drawio.svg` |

**Type Prefixes:** `use-case-`, `activity-`, `class-`, `state-machine-`, `deployment-`, `sequence-`

---

### Phase 6: Generate PRD

Create PRD in the new directory structure:

```
PRD/
└── {PRD-Name}/
    ├── PRD-{PRD-Name}.md
    └── Diagrams/
        ├── {Epic-1-Name}/
        │   ├── use-case-{description}.drawio.svg
        │   └── activity-{description}.drawio.svg
        └── {Epic-2-Name}/
            └── activity-{description}.drawio.svg
```

**Note:** Existing flat PRDs (`PRD/PRD-{name}.md`) are grandfathered. New PRDs use this directory structure.

Create PRD document in `PRD/{PRD-Name}/PRD-{PRD-Name}.md`:

```markdown
# PRD: <Feature Name>

**Status:** Draft
**Created:** <date>
**Source Proposal:** <proposal-path>

---

## Overview

<From proposal problem statement and solution>

---

## Epics

Group related stories by theme. Each epic becomes a GitHub epic issue.

### Epic 1: <Theme Name>
Stories: 1.1, 1.2, 1.3

### Epic 2: <Theme Name>
Stories: 2.1, 2.2

---

## User Stories

Stories are numbered by epic (1.1 = Epic 1, Story 1).

### Story 1.1: <Title>
**As a** <user type>
**I want** <capability>
**So that** <benefit>

**Acceptance Criteria:**
- [ ] <criterion 1>
- [ ] <criterion 2>

**Priority:** P0 - Must Have

### Story 1.2: <Title>
**As a** <user type>
**I want** <capability>
**So that** <benefit>

**Acceptance Criteria:**
- [ ] <criterion 1>

**Priority:** P1 - Should Have

### Story 2.1: <Title>
**As a** <user type>
**I want** <capability>
**So that** <benefit>

**Acceptance Criteria:**
- [ ] <criterion 1>

**Priority:** P2 - Could Have

---

## Diagrams

Visual documentation generated for this PRD:

| Epic | Diagram | Description |
|------|---------|-------------|
| Epic 1 | `Diagrams/Epic-1-Name/use-case-description.drawio.svg` | Actor interactions |
| Epic 1 | `Diagrams/Epic-1-Name/activity-description.drawio.svg` | Workflow steps |

> **Traceability:** Each diagram element cites its source (story ID, AC number).
> **Edit:** Open `.drawio.svg` files in draw.io for modifications.

---

## Technical Notes

> **These are implementation hints, not requirements.**
> **Do not create issues from this section.**

Implementation details collected during story transformation:

- File renames: <e.g., open-release.md → create-branch.md>
- Script path updates: <paths that need updating>
- Installer changes: <deployment considerations>
- Architecture notes: <aligned with Inception/Architecture.md>

---

## Out of Scope

<Explicit exclusions>

---

## Dependencies

<Cross-references to other work>

---

## Open Questions

<Unresolved items flagged during promotion>

---

*Generated by create-prd skill*
*Ready for Create-Backlog*
```

---

### Phase 7: Next Steps

After PRD generation, prompt:

```
PRD created: PRD/Feature-X/PRD-Feature-X.md

Diagrams (if generated):
  PRD/Feature-X/Diagrams/Epic-Name/use-case-description.drawio.svg
  PRD/Feature-X/Diagrams/Epic-Name/activity-description.drawio.svg

Next steps:
1. Review and edit the PRD
2. Run Create-Backlog to generate issues
3. Assign to release

Run Create-Backlog now? (yes/no)
```

---

## Extract Mode Workflow

For `/create-prd extract` or `/create-prd extract <directory>`:

### Step 1: Check Prerequisites

```
1. Check for Inception/ artifacts
2. If found: Load Inception/ context
3. If not found: Prompt for /charter
```

**No Inception/ Prompt:**
```
No Inception/ artifacts found.

For best results, run /charter first to establish project context.

Options:
1. Run /charter now (recommended)
2. Proceed without charter context
3. Cancel

> [user selects]
```

### Step 2: Load Codebase Analysis

Load `Skills/codebase-analysis/SKILL.md` for analysis capabilities:
- Tech stack detection
- Architecture inference
- Test parsing
- NFR detection

**Analysis Scope:**
```
Analyzing: <directory or entire project>

Tech Stack: [detected]
Architecture: [inferred]
Test Coverage: [found/not found]
```

### Step 3: Run Analysis

Execute codebase analysis commands:

| Command | Output |
|---------|--------|
| `Analyze-Tech-Stack` | Technology summary |
| `Analyze-Architecture` | Structure, layers, patterns |
| `Analyze-Tests` | Features from test descriptions |
| `Analyze-NFRs` | NFRs from code patterns |

### Step 4: Generate Draft PRD

Transform analysis into PRD structure:

| Analysis Output | PRD Section |
|-----------------|-------------|
| Tech stack | Technical Notes |
| Architecture | Technical Notes, Dependencies |
| Test features | User Stories (with confidence levels) |
| NFRs | Non-Functional Requirements |

**Confidence Levels:**
```markdown
### Story E.1: User Registration
**Confidence:** High
**Evidence:** test_user_registration.py (15 test cases)

**As a** new user
**I want** to register for an account
**So that** I can access the system

**Acceptance Criteria:**
- [ ] Email validation (test_email_validation)
- [ ] Password strength check (test_password_strength)
```

### Step 5: User Validation

Present extracted content for validation:

```
Extracted Features:
1. User Registration (High confidence)
2. User Authentication (High confidence)
3. Password Reset (Medium confidence - inferred from email service)

Which features should be included in the PRD?
[Select all that apply or type numbers]
```

### Step 6: Diagram Generation

Same workflow as promote mode (Phase 5.5):
- Diagram type selection
- Appropriateness guidance
- Content generation with traceability

### Step 7: Generate PRD

Same output format as promote mode (Phase 6), with additions:

```markdown
## Extraction Metadata

**Source:** Codebase analysis
**Analysis Date:** <date>
**Confidence Summary:**
- High: 5 stories
- Medium: 3 stories
- Low: 1 story (flagged for validation)

**Analysis Scope:** <directory or entire project>
```

---

## Integration with Other Components

| Component | Integration |
|-----------|-------------|
| **Proposals** | Input: `Proposal/<name>.md` (promote mode) |
| **Codebase** | Input: Project files (extract mode) |
| **codebase-analysis** | Analysis skill for extract mode |
| **Inception/** | Context: Scope, constraints, architecture |
| **CHARTER.md** | Validation: Scope alignment |
| **PRD/** | Output: `PRD/<name>/PRD-<name>.md` (new structure) |
| **Create-Backlog** | Downstream: Generates issues from PRD |

---

## Comparison: IDPF-PRD vs create-prd (Historical)

> **Note:** IDPF-PRD was deprecated in v0.24. This comparison shows why `create-prd` replaced it.

| Aspect | IDPF-PRD (deprecated) | create-prd |
|--------|----------------------|----------------|
| Phases | 4 formal phases | Single conversational flow |
| Input | Start from scratch | Proposal + Inception/ context |
| Questions | Static worksheets | Dynamic, context-aware |
| Validation | Manual review | Charter scope checking |
| Output | PRD after all phases | PRD incrementally built |
| Duration | Multiple sessions | Single session |
| Complexity | Comprehensive | Focused on gaps |

---

## Error Handling

**Promote Mode:**

| Situation | Response |
|-----------|----------|
| Proposal file not found | "Proposal not found at <path>. Check the path?" |
| No Inception/ artifacts | "No charter context found. Proceeding with limited validation." |
| User skips all questions | "Insufficient detail for PRD. Add more to proposal first?" |
| Proposal is empty/minimal | "Proposal needs more detail. Minimum: problem + proposed solution." |

**Extract Mode:**

| Situation | Response |
|-----------|----------|
| No test files found | "No tests detected. PRD extraction has low confidence without tests." |
| Directory not found | "Directory not found: <path>. Check the path?" |
| No code files found | "No analyzable code found in <path>." |
| Low confidence overall | "Extraction yielded mostly low-confidence features. Consider adding tests or documentation." |

---

## Quality Checklist

Before finalizing PRD:

- [ ] All user stories have acceptance criteria
- [ ] Requirements are prioritized (P0-P2)
- [ ] Priority distribution is valid (or <6 stories exempt)
- [ ] Technical Notes separated from user stories
- [ ] Out of scope is explicitly stated
- [ ] Open questions are flagged
- [ ] PRD is Create-Backlog compatible

**Diagram Quality (if diagrams generated):**

- [ ] Diagram types match epic context
- [ ] Appropriateness guidance followed
- [ ] All diagram elements trace to PRD source
- [ ] No invented actors, states, or interactions
- [ ] Diagrams use `.drawio.svg` format
- [ ] Files follow naming convention

---

**End of create-prd Skill**
