# Skill: create-prd
**Version:** {{VERSION}}
**Purpose:** Transform proposals into detailed PRD documents using Inception/ context
**Audience:** Developers promoting approved proposals to actionable requirements
**Load with:** Anti-Hallucination-Rules-for-PRD-Work.md
---
## Overview
Transform proposal documents into Product Requirements Documents (PRDs). Uses Inception/ artifacts for scope validation and generates targeted clarifying questions.
**Key Principle:** Proposals capture "what and why" at high level. PRDs add "how" with user stories, acceptance criteria, and prioritized requirements.
**Replaces:** IDPF-PRD 4-phase workflow (Discovery → Elicitation → Specification → Generation)
---
## When to Use
- Proposal approved and ready for implementation planning
- Need detailed requirements before Create-Backlog
- Want to validate proposal fits current charter scope
- Need user stories and acceptance criteria from high-level idea
---
## Skill Commands
| Command | Purpose |
|---------|---------|
| `/create-prd` | Interactive mode selection |
| `/create-prd <proposal-path>` | Transform proposal into PRD |
| `/create-prd extract` | Extract PRD from codebase |
| `/create-prd extract <directory>` | Extract PRD from specific directory |
---
## Process Flow
### Phase 1: Load Context
| File | Purpose | Required |
|------|---------|----------|
| `<proposal-path>` | The proposal to promote | Yes |
| `CHARTER.md` | Project vision and current focus | If exists |
| `Inception/Scope-Boundaries.md` | In-scope/out-of-scope items | If exists |
| `Inception/Constraints.md` | Technical/business constraints | If exists |
| `Inception/Architecture.md` | System architecture | If exists |
| `Inception/Charter-Details.md` | Full charter context | On-demand |
**If no Inception/ artifacts exist:** Proceed with proposal analysis only, flag limited validation, recommend `/charter` first.
---
### Phase 2: Validate Against Charter
| Check | Action if Misaligned |
|-------|---------------------|
| Fits in-scope items | Continue |
| Outside current scope | Ask: "This isn't in current scope. Expand scope?" |
| Conflicts with constraints | Flag conflict, ask for resolution |
| Depends on out-of-scope work | Identify dependencies |
---
### Phase 3: Analyze Proposal Gaps
| Element | How to Detect | Gap Action |
|---------|---------------|------------|
| Problem statement | "Problem:", "Issue:", first paragraph | Ask if missing |
| Proposed solution | "Solution:", "Approach:", section headers | Ask if missing |
| User stories | "As a...", "User can..." | Generate questions |
| Acceptance criteria | "- [ ]", "Done when", "Acceptance:" | Generate questions |
| Technical requirements | "Must support", "Requires", tech terms | Infer from constraints |
| Priority | "P0-P3", "High/Medium/Low" | Ask if missing |
| Scope boundaries | "Out of scope", "Not included" | Generate from context |
---
### Phase 4: Dynamic Question Generation
Generate questions based on gaps AND project context.
| Category | Trigger | Example Questions |
|----------|---------|-------------------|
| Users | No user stories | "Who are the primary users of [feature]?" |
| Workflow | Vague solution | "What's the main workflow for [feature]?" |
| Done criteria | No acceptance criteria | "What does 'done' look like for this?" |
| Constraints | Architecture implications | "Any constraints from current architecture?" |
| Priority | No priority stated | "Priority relative to other work?" |
| Edge cases | Complex feature | "What edge cases should we handle?" |
| Dependencies | Cross-cutting concern | "Does this depend on other work?" |
**Rules:** Context-aware, Minimal (only what's missing), Specific, Actionable
**Asking:** 3-5 questions at a time, conversational tone, allow "skip" responses, adapt follow-ups
---
### Phase 4.5: Story Transformation
Transform requirements into Agile user stories.
**Anti-Pattern Detection:**
| Anti-Pattern | Indicators | Action |
|--------------|------------|--------|
| File operations | "rename file", "move to", file paths | Flag as Technical Note |
| Internal changes | "refactor", "update config", "script changes" | Flag as Technical Note |
| Code-level details | function names, class names, module references | Flag as Technical Note |
| System internals | "installer", "deployment", "registry" | Flag as Technical Note |
**Transformation Questions:**
| Question | Purpose |
|----------|---------|
| "Who uses this feature?" | Identify user persona |
| "What can they do with it?" | Identify capability |
| "Why does that matter to them?" | Identify benefit |
| "What proves it's working?" | Generate acceptance criteria |
---
### Phase 5: Priority Validation
| Priority | Required Distribution |
|----------|----------------------|
| P0 (Must Have) | ≤40% of stories |
| P1 (Should Have) | 30-40% of stories |
| P2 (Could Have) | ≥20% of stories |
**Small PRD Exemption:** PRDs with <6 stories exempt from distribution validation.
**Prioritization Questions:**
| Question | Purpose |
|----------|---------|
| "If you could only ship 3, which would they be?" | Identify true P0s |
| "Which are nice-to-have but not critical?" | Identify P2s |
| "What's blocked if [story] isn't done?" | Validate P0 dependencies |
| "Could v1 launch without [story]?" | Challenge P0 classification |
---
### Phase 5.5: Diagram Generation (Optional)
**Supported Diagram Types:**
| Diagram Type | Default | Purpose |
|--------------|---------|---------|
| Use Case | ON | Actor interactions, feature scope |
| Activity | ON | Workflows, decision points |
| Class | OFF | Domain models, data structures |
| State Machine | OFF | Lifecycle flows, status transitions |
| Deployment | OFF | Infrastructure, system topology |
| Sequence | OFF | Component interactions, API flows |
**Appropriateness Matrix:**
| Diagram Type | Appropriate When | Not Appropriate When |
|--------------|------------------|----------------------|
| Use Case | User-facing features, actor interactions | Pure technical/infrastructure changes |
| Activity | Multi-step workflows, decision points | Simple CRUD operations |
| Class | Domain models, data structures, OOP design | Script-only changes, config updates |
| State Machine | Lifecycle flows, status transitions | Simple flag toggles |
| Deployment | Infrastructure, system topology | Single-service changes |
| Sequence | API interactions, multi-component flows | Internal method calls |
**Qualifiers:** Complexity threshold, Epic size (≥3 stories), Integration scope, Novelty, Audience
**Content Source:**
| Diagram Type | Content Source |
|--------------|----------------|
| Use Case | Actors from PRD personas and "As a..." clauses |
| Activity | Steps from acceptance criteria and workflow descriptions |
| Sequence | Interactions from documented behavior and Technical Notes |
| Class | Entities from data models mentioned in stories |
| State Machine | States/transitions from acceptance criteria |
| Deployment | Components from Technical Notes and architecture |
**Format:** `.drawio.svg` (SVG with embedded draw.io XML)
**Naming:** `{type}-{description}.drawio.svg` (e.g., `use-case-branch-operations.drawio.svg`)
---
### Phase 6: Generate PRD
**Directory Structure:**
```
PRD/
└── {PRD-Name}/
    ├── PRD-{PRD-Name}.md
    └── Diagrams/
        └── {Epic-Name}/
            └── {type}-{description}.drawio.svg
```
**PRD Template:**
```markdown
# PRD: <Feature Name>
**Status:** Draft
**Created:** <date>
**Source Proposal:** <proposal-path>
---
## Overview
<From proposal problem statement and solution>
---
## Epics
### Epic 1: <Theme Name>
Stories: 1.1, 1.2, 1.3
---
## User Stories
### Story 1.1: <Title>
**As a** <user type>
**I want** <capability>
**So that** <benefit>
**Acceptance Criteria:**
- [ ] <criterion 1>
**Priority:** P0 - Must Have
---
## Diagrams
| Epic | Diagram | Description |
|------|---------|-------------|
| Epic 1 | `Diagrams/Epic-1-Name/use-case-description.drawio.svg` | Actor interactions |
---
## Technical Notes
> Implementation hints, not requirements. Do not create issues from this section.
---
## Out of Scope
<Explicit exclusions>
---
## Dependencies
<Cross-references to other work>
---
## Open Questions
<Unresolved items>
---
*Generated by create-prd skill*
*Ready for Create-Backlog*
```
---
### Phase 7: Next Steps
```
PRD created: PRD/Feature-X/PRD-Feature-X.md
Next steps:
1. Review and edit the PRD
2. Run Create-Backlog to generate issues
3. Assign to release
Run Create-Backlog now? (yes/no)
```
---
## Extract Mode Workflow
For `/create-prd extract` or `/create-prd extract <directory>`:
### Step 1: Check Prerequisites
Check for Inception/ artifacts. If not found, prompt for /charter.
### Step 2: Load Codebase Analysis
Load `Skills/codebase-analysis/SKILL.md` for analysis:
- Tech stack detection
- Architecture inference
- Test parsing
- NFR detection
### Step 3: Run Analysis
| Command | Output |
|---------|--------|
| `Analyze-Tech-Stack` | Technology summary |
| `Analyze-Architecture` | Structure, layers, patterns |
| `Analyze-Tests` | Features from test descriptions |
| `Analyze-NFRs` | NFRs from code patterns |
### Step 4: Generate Draft PRD
| Analysis Output | PRD Section |
|-----------------|-------------|
| Tech stack | Technical Notes |
| Architecture | Technical Notes, Dependencies |
| Test features | User Stories (with confidence levels) |
| NFRs | Non-Functional Requirements |
### Step 5: User Validation
Present extracted features with confidence levels for user selection.
### Step 6-7: Diagram Generation and PRD Generation
Same as promote mode (Phases 5.5-6), with extraction metadata:
```markdown
## Extraction Metadata
**Source:** Codebase analysis
**Analysis Date:** <date>
**Confidence Summary:** High: X, Medium: Y, Low: Z
**Analysis Scope:** <directory or entire project>
```
---
## Integration
| Component | Integration |
|-----------|-------------|
| **Proposals** | Input: `Proposal/<name>.md` (promote mode) |
| **Codebase** | Input: Project files (extract mode) |
| **codebase-analysis** | Analysis skill for extract mode |
| **Inception/** | Context: Scope, constraints, architecture |
| **CHARTER.md** | Validation: Scope alignment |
| **PRD/** | Output: `PRD/<name>/PRD-<name>.md` |
| **Create-Backlog** | Downstream: Generates issues from PRD |
---
## Error Handling
**Promote Mode:**
| Situation | Response |
|-----------|----------|
| Proposal file not found | "Proposal not found at <path>. Check the path?" |
| No Inception/ artifacts | "No charter context found. Proceeding with limited validation." |
| User skips all questions | "Insufficient detail for PRD. Add more to proposal first?" |
| Proposal is empty/minimal | "Proposal needs more detail. Minimum: problem + proposed solution." |
**Extract Mode:**
| Situation | Response |
|-----------|----------|
| No test files found | "No tests detected. PRD extraction has low confidence without tests." |
| Directory not found | "Directory not found: <path>. Check the path?" |
| No code files found | "No analyzable code found in <path>." |
| Low confidence overall | "Extraction yielded mostly low-confidence features. Consider adding tests." |
---
## Quality Checklist
- [ ] All user stories have acceptance criteria
- [ ] Requirements prioritized (P0-P2)
- [ ] Priority distribution valid (or <6 stories exempt)
- [ ] Technical Notes separated from user stories
- [ ] Out of scope explicitly stated
- [ ] Open questions flagged
- [ ] PRD is Create-Backlog compatible
**Diagram Quality (if generated):**
- [ ] Diagram types match epic context
- [ ] Appropriateness guidance followed
- [ ] All elements trace to PRD source
- [ ] No invented actors, states, or interactions
- [ ] Uses `.drawio.svg` format
- [ ] Follows naming convention
---
**End of create-prd Skill**
