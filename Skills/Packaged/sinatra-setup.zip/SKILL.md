---
name: sinatra-setup-for-beginners
description: Set up Ruby Sinatra development environment for beginners with step-by-step guidance, Bundler setup, and troubleshooting
version: "0.42.2"
license: Complete terms in LICENSE.txt
---

# Sinatra Setup for Beginners

This Skill guides complete beginners through setting up a Sinatra development environment with detailed explanations and verification steps.

## When to Use This Skill

Invoke this Skill when:
- User wants to build a Sinatra web application
- User is a beginner and needs Sinatra environment setup
- User asks "How do I set up Sinatra?" or "How do I start a Sinatra project?"
- Project type is determined to be web application using Sinatra/Ruby

## Instructions for ASSISTANT

**CRITICAL OUTPUT FORMAT:**

When using this Skill's content, the ASSISTANT must format ALL technical instructions as **Claude Code copy/paste blocks**.

**DO NOT provide manual instructions like:**
- ❌ "Open File Explorer"
- ❌ "Navigate to folder"
- ❌ "Right-click"

**ALWAYS format as:**
```
TASK: Set up Sinatra project

STEP 1: Copy this entire code block (including this line)
STEP 2: Open Claude Code
STEP 3: Paste into Claude Code
STEP 4: Claude Code will execute and report results
STEP 5: Report back: What did Claude Code say?

---

[Instructions for Claude Code to execute:]

Navigate to project directory:
cd [project-location]

Create project folder:
mkdir [project-name]
cd [project-name]

Verify Ruby installed:
ruby --version

[continue with commands...]

Report:
- What results did you see?
```

## Setup Knowledge

The following content provides setup knowledge. ASSISTANT must convert this into Claude Code commands:

### STEP 1: Create Project and Verify Ruby

**Command:**
```bash
ruby --version
```

**Expected output:** `ruby 3.0.0` or higher (e.g., `ruby 3.2.2`)

**What this checks:**
- Ruby is installed on your system
- Ruby is accessible from the command line
- Which version you have

**If Ruby is NOT installed:**

**Windows:**
- Download RubyInstaller from https://rubyinstaller.org/
- Choose "Ruby+Devkit 3.2.X" version
- Run installer with default settings
- Check "Add Ruby to PATH" during installation
- Restart terminal after installation

**Mac:**
- Ruby comes pre-installed, but might be old
- For latest version, use Homebrew:
  ```bash
  brew install ruby
  ```
- Or use rbenv for version management

**Linux (Ubuntu/Debian):**
```bash
sudo apt-get update
sudo apt-get install ruby-full
```

**After installing Ruby, verify again:**
```bash
ruby --version
```

### STEP 4: Install Bundler

**Command:**
```bash
gem install bundler
```

**What this does:**
- Installs Bundler, Ruby's package manager
- Bundler manages gem (package) dependencies for your project
- Similar to pip for Python or npm for JavaScript

**Why we need Bundler:**
- Manages gem versions consistently
- Ensures everyone has the same dependencies
- Makes project portable and reproducible

**Wait time:** 10-30 seconds

**Success message:** "Successfully installed bundler-X.X.X"

**Verify installation:**
```bash
bundler --version
```

**Expected:** `Bundler version 2.X.X`

**Common issues:**
- "Permission denied" → Use `sudo gem install bundler` (Mac/Linux)
- "gem: command not found" → Ruby not installed properly

### STEP 5: Create Gemfile

**What is a Gemfile?**
A Gemfile lists all the Ruby gems (packages) your project needs. It's like requirements.txt for Python or package.json for Node.js.

**Instructions:**
1. Open your text editor
2. Create a new file
3. Save it as `Gemfile` (no extension! Just "Gemfile")
4. Save it in your project folder

**File location:**
```
my-project/
└── Gemfile  ← Create this file
```

**Content to put in Gemfile:**
```ruby
source 'https://rubygems.org'

gem 'sinatra'
```

**Explanation of each line:**
- `source 'https://rubygems.org'` - Where to download gems from
- `gem 'sinatra'` - The Sinatra gem we want to install

**Important:**
- File must be named exactly `Gemfile` (capital G, no extension)
- Must be in the project root directory
- Use straight quotes (''), not curly quotes ('')

### STEP 6: Install Sinatra and Dependencies

**Command:**
```bash
bundle install
```

**What this does:**
- Reads your Gemfile
- Downloads Sinatra and its dependencies
- Installs them in your project
- Creates `Gemfile.lock` (don't edit this file!)

**Wait time:** 30-90 seconds (downloads and installs)

**You'll see:**
```
Fetching gem metadata from https://rubygems.org/
Resolving dependencies...
Installing rack X.X.X
Installing tilt X.X.X
Installing rack-protection X.X.X
Installing sinatra X.X.X
Bundle complete!
```

**What gets installed:**
- Sinatra (the web framework)
- Rack (web server interface)
- Rack Protection (security middleware)
- Tilt (template engine interface)

**After installation, you'll have:**
```
my-project/
├── Gemfile        ← You created this
└── Gemfile.lock   ← Bundle created this (version lock file)
```

**Common issues:**
- "Could not locate Gemfile" → Make sure you're in project directory
- "Permission denied" → Use `bundle install --path vendor/bundle`
- Network errors → Check internet connection

### STEP 7: Create app.rb File

**Instructions:**
1. Open your text editor
2. Create a new file
3. Save it as `app.rb` in your project folder

**Recommended editors for beginners:**
- **VS Code**: Free, powerful, good Ruby support
- **RubyMine**: Ruby-focused IDE
- **Sublime Text**: Fast, simple
- **Atom**: Free, GitHub-made

**File location should be:**
```
my-project/
├── Gemfile
├── Gemfile.lock
└── app.rb       ← Your main Sinatra file (create this)
```

### STEP 8: Verify Installation

**Command 1: Check Ruby version**
```bash
ruby --version
```

**Expected:** `ruby 3.0.0` or higher

**Command 2: Check Bundler**
```bash
bundle --version
```

**Expected:** `Bundler version 2.X.X`

**Command 3: Check installed gems**
```bash
bundle list
```

**Expected output includes:**
```
Gems included by the bundle:
  * sinatra (X.X.X)
  * rack (X.X.X)
  * rack-protection (X.X.X)
  * tilt (X.X.X)
```

**Command 4: Test Sinatra import**
```bash
ruby -e "require 'sinatra'; puts 'Sinatra works!'"
```

**Expected output:** `Sinatra works!`

**All checks pass?** You're ready to start coding!

### STEP 9: Report Completion

**Report to the ASSISTANT:**
- "Setup complete! Bundle installed successfully and I can see Sinatra in my gem list"
- Or if issues: "I got stuck at step X with error: [exact error message]"

## What Happens Next

After successful setup:
1. ASSISTANT will guide you through creating your first Sinatra route
2. You'll write "Hello World" application
3. You'll start the Sinatra server
4. You'll see your first web page in a browser

## Troubleshooting Quick Reference

See `resources/verification-checklist.md` for detailed troubleshooting steps.

**Most common issues:**
1. **Ruby not installed** → Follow Step 3 installation instructions
2. **Gemfile in wrong location** → Must be in project root
3. **Permission errors** → Use `bundle install --path vendor/bundle`
4. **Network/firewall issues** → Check internet connection
5. **Old Ruby version** → Update Ruby to 3.0+

## Project Structure Summary

After setup, you should have:
```
my-project/
├── Gemfile           ← Gem dependencies (you created)
├── Gemfile.lock      ← Version lock (bundle created)
└── app.rb            ← Your code (you created)
```

Later you'll add:
```
my-project/
├── Gemfile
├── Gemfile.lock
├── app.rb
├── views/            ← Templates (.erb files)
│   └── index.erb
└── public/           ← Static files (CSS, images, JS)
    └── style.css
```

## Next Steps

Once setup is complete:
- Create your first Sinatra route
- Learn about Sinatra's DSL (Domain Specific Language)
- Understand the request/response cycle
- Build your first web page

---

**Remember:** Run `bundle exec ruby app.rb` to start your Sinatra app (bundle exec ensures correct gem versions)
