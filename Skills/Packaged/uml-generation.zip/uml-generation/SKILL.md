---
name: uml-generation
description: Generate UML diagrams from project source code using PlantUML with online rendering
version: "0.34.1"
license: Complete terms in LICENSE.txt
---

# UML Generation Skill

## Purpose

Analyze project source code and generate UML diagrams with PlantUML syntax and online rendering URLs. Provides visual documentation of code structure, relationships, and behavior during code analysis.

---

## When to Invoke

- **Code analysis** requiring visual documentation
- **Architecture review** and documentation
- **Reverse-engineering** existing codebases
- **Understanding class hierarchies** and relationships
- **Documenting API call flows** and sequences
- **Technical debt visualization** (with anti-pattern-analysis)
- **PRD extraction** (with extract-prd skill)

---

## Capabilities

### Supported Diagram Types

| Diagram | Use Case | Priority |
|---------|----------|----------|
| **Class Diagram** | Code structure, inheritance, associations | High |
| **Sequence Diagram** | Method call flows, API interactions | High |
| **Component Diagram** | Architecture, module dependencies | Medium |
| **Activity Diagram** | Workflow logic, algorithms | Medium |
| **State Diagram** | State machines, lifecycle | Low |

### What Gets Extracted

**Class Diagrams:**
- Classes, interfaces, abstract classes, enums
- Inheritance (`extends`) and implementation (`implements`)
- Associations, aggregations, compositions
- Visibility modifiers (+public, -private, #protected, ~package)
- Methods with parameters and return types
- Properties/fields with types

**Sequence Diagrams:**
- Method call chains
- Request/response patterns
- Async operations and callbacks
- Error handling flows
- Participant lifelines

**Component Diagrams:**
- Module/package structure
- Dependencies between components
- Interfaces and ports
- Layer boundaries

---

## Output Format

Each generated diagram includes three parts:

### 1. PlantUML Source (Copyable)
```plantuml
@startuml
class User {
  +id: int
  +name: string
  +email: string
  +getOrders(): List<Order>
}

class Order {
  +id: int
  +total: decimal
  +status: string
}

User "1" --> "*" Order : places
@enduml
```

### 2. Online Rendering URL
```
View: http://www.plantuml.com/plantuml/svg/[encoded]
```

### 3. Download Links
```
SVG: http://www.plantuml.com/plantuml/svg/[encoded]
PNG: http://www.plantuml.com/plantuml/png/[encoded]
```

---

## How to Use

### Generate Class Diagram

**Request:** "Generate a class diagram for the models in src/models/"

**Process:**
1. Read all files in specified directory
2. Extract class definitions, relationships
3. Generate PlantUML syntax
4. Encode and create URL
5. Output source + links

### Generate Sequence Diagram

**Request:** "Create a sequence diagram showing the checkout flow"

**Process:**
1. Identify entry point (e.g., `checkout()` method)
2. Trace method calls through codebase
3. Identify participants (classes/services)
4. Generate PlantUML sequence syntax
5. Output source + links

### Generate Component Diagram

**Request:** "Show the architecture of the backend services"

**Process:**
1. Analyze directory/module structure
2. Identify dependencies between modules
3. Map to PlantUML components
4. Output source + links

---

## PlantUML Quick Reference

### Class Diagram Syntax

```plantuml
@startuml
' Classes
class ClassName {
  +publicField: Type
  -privateField: Type
  #protectedField: Type
  ~packageField: Type
  +publicMethod(): ReturnType
  -privateMethod(param: Type): void
}

' Relationships
ClassA <|-- ClassB        : inheritance
ClassA <|.. ClassB        : implementation
ClassA *-- ClassB         : composition
ClassA o-- ClassB         : aggregation
ClassA --> ClassB         : association
ClassA ..> ClassB         : dependency

' Multiplicity
ClassA "1" --> "*" ClassB : one-to-many
ClassA "0..1" --> "1..*" ClassB
@enduml
```

### Sequence Diagram Syntax

```plantuml
@startuml
participant Client
participant Server
participant Database

Client -> Server: request()
activate Server
Server -> Database: query()
activate Database
Database --> Server: results
deactivate Database
Server --> Client: response
deactivate Server

' Alternatives
alt success
  Server --> Client: 200 OK
else error
  Server --> Client: 500 Error
end
@enduml
```

### Component Diagram Syntax

```plantuml
@startuml
package "Frontend" {
  [Web App]
  [Mobile App]
}

package "Backend" {
  [API Gateway]
  [User Service]
  [Order Service]
}

database "Database" {
  [PostgreSQL]
}

[Web App] --> [API Gateway]
[Mobile App] --> [API Gateway]
[API Gateway] --> [User Service]
[API Gateway] --> [Order Service]
[User Service] --> [PostgreSQL]
[Order Service] --> [PostgreSQL]
@enduml
```

---

## URL Encoding

PlantUML uses a custom encoding for URLs:

1. **UTF-8 encode** the PlantUML source
2. **Deflate compress** the bytes
3. **Base64-like encode** using PlantUML's alphabet: `0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz-_`
4. **Construct URL:** `http://www.plantuml.com/plantuml/svg/{encoded}`

**URL Length Limit:** ~2000 characters (browser limit)

For diagrams exceeding this limit, output source only with instructions to use a local PlantUML installation.

---

## Integration Points

### With extract-prd Skill

```
Reverse-PRD Workflow:
1. extract-prd analyzes code structure
2. uml-generation creates class/component diagrams
3. Combined output includes visual architecture documentation
```

### With anti-pattern-analysis Skill

```
Code Review Workflow:
1. anti-pattern-analysis identifies God Objects
2. uml-generation visualizes the problematic class
3. Diagram shows why refactoring is needed
```

### With Domain Specialists

| Specialist | UML Use Case |
|------------|--------------|
| Backend-Specialist | Service layer class diagrams |
| Database-Engineer | Entity relationships in context |
| API-Integration-Specialist | Sequence diagrams for API flows |
| Frontend-Specialist | Component hierarchy diagrams |

---

## Limitations (Phase 1)

| Limitation | Impact | Workaround |
|------------|--------|------------|
| Internet required | Cannot work offline | Use PlantUML locally (Phase 2) |
| URL length ~2000 chars | Large diagrams truncated | Output source only |
| Public server | Code visible to PlantUML | Self-host (Phase 2) |
| No caching | Re-generates each time | Copy URLs/source |

---

## Resources

- [Class Diagram Guide](resources/class-diagram-guide.md) - Full syntax reference
- [Sequence Diagram Guide](resources/sequence-diagram-guide.md) - Flow documentation
- [Component Diagram Guide](resources/component-diagram-guide.md) - Architecture diagrams
- [PlantUML Encoding](resources/plantuml-encoding.md) - URL encoding details
- [Python to UML](resources/language-patterns/python-to-uml.md) - Python extraction patterns
- [JavaScript to UML](resources/language-patterns/javascript-to-uml.md) - JS/TS extraction patterns

---

## Related

- **extract-prd**: Code analysis for PRD extraction
- **anti-pattern-analysis**: Code quality visualization
- **Phase 2**: Local PlantUML integration (Issue #64)

---

**End of Skill Document**
