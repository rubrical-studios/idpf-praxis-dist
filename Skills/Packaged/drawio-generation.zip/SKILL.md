---
name: drawio-generation
description: Generate valid .drawio.svg diagrams with editable mxGraphModel structure
version: "0.42.2"
license: Complete terms in LICENSE.txt
keywords: [drawio, svg, diagram, uml, mxgraph, activity, use-case, sequence]
---
# DrawIO Generation Skill
**Purpose:** Technical specification for generating `.drawio.svg` files — dual-representation format that renders as SVG while remaining fully editable in draw.io.
**Audience:** Commands, extensions, or workflows that produce UML or architectural diagrams.
**Load with:** `Skills/drawio-generation/SKILL.md`
---
## When to Use This Skill
Invoke when:
- Generating UML diagrams (use case, activity, sequence, class, component, state)
- Creating architectural diagrams for PRDs or design documents
- Producing `.drawio.svg` files that must open and edit correctly in draw.io
- Validating existing `.drawio.svg` files for completeness
---
## File Format: Dual SVG + mxGraphModel Representation
A `.drawio.svg` file is standard SVG with embedded `mxfile` XML in the `<svg>` element's `content` attribute:
- **SVG layer** — renders in browsers, GitHub, image viewers
- **mxGraphModel layer** — stores editable graph structure for draw.io
Both layers must describe the **same diagram**.
### File Structure
```xml
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE svg PUBLIC "-//W3C//DTD SVG 1.1//EN" "http://www.w3.org/Graphics/SVG/1.1/DTD/svg11.dtd">
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink"
     width="600" height="400" viewBox="0 0 600 400"
     content="&lt;mxfile ...&gt;...HTML-encoded mxGraphModel XML...&lt;/mxfile&gt;"
     style="background-color: rgb(255, 255, 255);">
  <defs/>
  <g>
    <!-- SVG shapes and lines that visually match the mxGraphModel -->
  </g>
</svg>
```
Key points:
- `content` attribute contains entire mxfile XML, HTML-encoded (`<` → `&lt;`, `"` → `&quot;`)
- `width`, `height`, `viewBox` on `<svg>` match `dx`/`dy` on `<mxGraphModel>`
- SVG elements inside `<g>` are visual rendering; `content` is editable model
---
## mxGraphModel Structure
Strict hierarchy:
```
mxfile
 └── diagram (id, name)
      └── mxGraphModel (dx, dy, grid, gridSize, ...)
           └── root
                ├── mxCell id="0"              ← root container (always present)
                ├── mxCell id="1" parent="0"   ← default layer (always present)
                ├── mxCell id="..." vertex="1" ← shape cells
                ├── mxCell id="..." edge="1"   ← edge cells
                └── ...
```
### Required Root Cells
Every mxGraphModel must start with:
```xml
<mxCell id="0"/>
<mxCell id="1" parent="0"/>
```
- Cell `0` is root container
- Cell `1` is default layer; all other cells use `parent="1"`
### Shape mxCell (vertex)
Shapes are `mxCell` with `vertex="1"` and child `mxGeometry`:
```xml
<mxCell id="step1"
        value="Step 1: Build Model"
        style="rounded=1;whiteSpace=wrap;html=1;fillColor=#E3F2FD;strokeColor=#1976D2;"
        vertex="1" parent="1">
  <mxGeometry x="110" y="90" width="280" height="80" as="geometry"/>
</mxCell>
```
| Attribute | Purpose |
|-----------|---------|
| `id` | Unique identifier (referenced by edges) |
| `value` | Display text (use `&#10;` for line breaks) |
| `style` | Semicolon-delimited style properties |
| `vertex="1"` | Marks as shape (not edge) |
| `parent="1"` | Belongs to default layer |
`mxGeometry` defines position (`x`, `y`) and size (`width`, `height`).
### Edge mxCell (edge)
Edges connect shapes using `edge="1"` with `source` and `target`:
```xml
<mxCell id="e1"
        value=""
        style="edgeStyle=orthogonalEdgeStyle;endArrow=block;endFill=1;"
        edge="1" parent="1"
        source="step1" target="step2">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```
| Attribute | Purpose |
|-----------|---------|
| `id` | Unique identifier |
| `value` | Edge label (empty for unlabeled) |
| `style` | Edge style (orthogonal, curved, endArrow type) |
| `edge="1"` | Marks as edge (not shape) |
| `source` | ID of source shape |
| `target` | ID of target shape |
`mxGeometry` for edges uses `relative="1"`.
### Edge Labels
Add label via `value` attribute:
```xml
<mxCell id="e5" value="No"
        style="edgeStyle=orthogonalEdgeStyle;endArrow=block;endFill=1;"
        edge="1" parent="1"
        source="decision" target="fix">
  <mxGeometry relative="1" as="geometry"/>
</mxCell>
```
---
## Critical Requirement: SVG ↔ mxGraphModel Synchronization
> **Every SVG visual element must have a corresponding mxCell in mxGraphModel, and vice versa.**
Violations cause:
- **Missing mxCell for SVG arrow** — renders but not editable (ghost element)
- **Missing SVG for mxCell** — exists in editor but invisible in rendered SVG
- **Mismatched coordinates** — appears in different locations in editor vs. render
### Synchronization Checklist
| Check | Verify |
|-------|--------|
| Shape count | Number of `vertex="1"` mxCells = SVG shapes (`<rect>`, `<ellipse>`, `<polygon>`) |
| Edge count | Number of `edge="1"` mxCells = SVG lines/paths (`<line>`, `<path>`) |
| Coordinates | `mxGeometry x,y` matches SVG element `x,y` (or `cx,cy` for ellipses) |
| Labels | `mxCell value` matches SVG `<text>` content |
| Connections | Every `source`/`target` references valid shape ID |
### Common Anti-Pattern
```
WRONG: Draw SVG arrows first, then add edge mxCells later
RIGHT: Build mxGraphModel first, then generate matching SVG (model-first approach)
```
---
## Generation Pattern: Model-First Approach
Generate in three sequential steps. Never skip or reorder.
### Step 1: Build mxGraphModel
Create complete graph model before SVG:
1. **Create shape mxCells** — one `vertex="1"` per visual element
2. **Create edge mxCells** — one `edge="1"` per connection with `source`/`target`
3. **Assign unique IDs** — use semantic names (e.g., `step1`, `decision`, `e1`)
4. **Calculate geometry** — set `x`, `y`, `width`, `height` without overlap (use 10px grid)
**Output:** Complete `<mxfile>` XML with all shapes and edges.
### Step 2: Generate SVG
Translate each mxCell to SVG:
| mxCell Type | SVG Element | Coordinate Source |
|-------------|-------------|-------------------|
| `vertex="1"` with `rounded=1` | `<rect rx="10" ry="10">` | `mxGeometry x, y, width, height` |
| `vertex="1"` with `ellipse` | `<ellipse>` | `cx = x + width/2`, `cy = y + height/2`, `rx = width/2`, `ry = height/2` |
| `vertex="1"` with `rhombus` | `<polygon>` (4 points) | Derived from center and size |
| `vertex="1"` with `shape=umlActor` | `<circle>` + `<line>` | Head at `(x + width/2, y + 10)` |
| `edge="1"` | `<line>` or `<path>` | From source/target positions |
| `mxCell value` text | `<text>` | Centered in shape |
**Coordinate alignment rule:** SVG positions must match `mxGeometry` exactly.
### Step 3: Validate Synchronization
Before finalizing:
1. **Count matching** — `vertex="1"` count = SVG shapes; `edge="1"` count = SVG lines/paths
2. **Edge reference verification** — every `source`/`target` references existing shape `id`
3. **Label matching** — `mxCell value` text in corresponding SVG `<text>`
4. **Coordinate spot-check** — verify first and last shape positions match
If validation fails, fix **mxGraphModel first**, then regenerate SVG.
### Anti-Pattern Warning
> **Never write SVG elements without first creating the mxGraphModel equivalent.**
Writing SVG first causes:
- Edge `source`/`target` pointing to nonexistent IDs
- Shape IDs in mxGraphModel don't match SVG
- Coordinates drift between layers
Model-first prevents all three problems.
---
## Validation Checklist
After generating `.drawio.svg`, verify all categories pass.
### 1. mxGraphModel Completeness
- [ ] Root cells present: `<mxCell id="0"/>` and `<mxCell id="1" parent="0"/>`
- [ ] Every shape has `vertex="1"` and child `<mxGeometry>` with `x`, `y`, `width`, `height`
- [ ] Every edge has `edge="1"` with `source` and `target`
- [ ] Every `source`/`target` references valid shape `id`
- [ ] Every edge `mxGeometry` has `relative="1"`
- [ ] All `id` values unique
- [ ] All cells have `parent="1"` (or appropriate parent)
### 2. SVG ↔ mxGraphModel Synchronization
- [ ] Shape count matches: `vertex="1"` mxCells = SVG shapes
- [ ] Edge count matches: `edge="1"` mxCells = SVG lines/paths
- [ ] Coordinates aligned: `mxGeometry x,y` matches SVG positioning
- [ ] Labels match: `mxCell value` in SVG `<text>`
- [ ] `<svg>` dimensions match `<mxGraphModel>` `dx`, `dy`
- [ ] `content` attribute contains complete HTML-encoded mxfile XML
### 3. Story Traceability (for PRD diagrams)
- [ ] **Use case diagrams:** Each user story maps to use case ellipse with story reference
- [ ] **Activity diagrams:** Acceptance criteria steps map to activity nodes
- [ ] **All diagrams:** Story IDs embedded in labels/annotations for traceability
- [ ] Diagram title references epic or feature
### 4. Editability Verification
- [ ] Opens in draw.io without errors
- [ ] Shapes selectable and movable
- [ ] Connectors re-route when shapes moved
- [ ] Text labels editable by double-clicking
- [ ] Adding new shapes/connectors doesn't break existing elements
---
