---
name: sqlite-integration-for-beginners
description: Add SQLite database to Flask or Sinatra app with beginner-friendly code examples and teaching comments
version: "0.34.1"
license: Complete terms in LICENSE.txt
---

# SQLite Integration for Beginners

This Skill teaches beginners how to add persistent data storage using SQLite to their Flask or Sinatra applications.

## When to Use This Skill

Invoke this Skill when:
- User has working app with in-memory storage (lists/arrays)
- User asks "How do I save data permanently?"
- User wants data to persist after server restart
- User mentions "database" but is a beginner
- User has 3-4 features working and is ready for persistence

## Prerequisites Check

Before adding database, user should:
- ✓ Have working Flask or Sinatra app
- ✓ Understand routes and templates
- ✓ Have at least one feature using list/array storage
- ✓ Understand the "data disappears on restart" problem
- ✓ Be comfortable with basic programming concepts

## What is SQLite?

**Beginner explanation:**
```
SQLite is a database that stores data in a file.

Think of it like this:
- List/Array: Like writing notes on a whiteboard
  - Fast and easy
  - Disappears when you turn off the server (erase board)

- SQLite: Like writing in a notebook
  - Data saved to a file (notes.db)
  - Stays there even after server stops
  - Can search, sort, and organize data easily

Perfect for beginners because:
✓ No server setup needed
✓ Just a file in your project
✓ Built into Python
✓ Easy to learn SQL basics
✓ Can upgrade to PostgreSQL/MySQL later
```

## Key Concepts to Teach

### 1. Database = Organized Storage
```
Database has TABLES (like spreadsheets)
Each table has:
- COLUMNS: What kind of data (id, name, email)
- ROWS: Actual data entries

Example "notes" table:
┌────┬─────────────────┬────────────────────┐
│ id │ text            │ created_at         │
├────┼─────────────────┼────────────────────┤
│ 1  │ Buy milk        │ 2024-01-15 10:30   │
│ 2  │ Call doctor     │ 2024-01-15 11:45   │
│ 3  │ Finish homework │ 2024-01-15 14:20   │
└────┴─────────────────┴────────────────────┘
```

### 2. SQL = Language for Databases
```
SQL (Structured Query Language) tells database what to do:

CREATE TABLE - Make new table
INSERT INTO  - Add data
SELECT       - Get data
UPDATE       - Change data
DELETE       - Remove data

It reads almost like English!
```

### 3. Connection = Open the Database File
```
Before using database:
1. CONNECT to database file (open it)
2. DO something (add, get, update data)
3. COMMIT (save changes)
4. CLOSE connection (close the file)

Like opening a notebook, writing something, closing it.
```

## Implementation Steps

### Step 1: Understand the Transition

**Current code (using list):**
```python
notes = []  # Data in RAM - disappears when server stops

@app.route('/')
def home():
    return render_template('index.html', notes=notes)

@app.route('/add', methods=['POST'])
def add():
    notes.append(request.form['note'])
    return redirect('/')
```

**Problem:** Restart server → notes disappear

**After adding SQLite:** Data saved in `notes.db` file → persists forever

### Step 2: Choose Your Framework

Direct user to appropriate example:
- **Flask users:** See `resources/flask-sqlite-example.py`
- **Sinatra users:** See `resources/sinatra-sqlite-example.rb`
- **SQL basics:** See `resources/sql-basics.md`

## Flask Implementation

See `resources/flask-sqlite-example.py` for complete, commented code.

**Key changes from list to SQLite:**

**1. Import sqlite3:**
```python
import sqlite3
```

**2. Create connection function:**
```python
def get_db():
    conn = sqlite3.connect('notes.db')
    conn.row_factory = sqlite3.Row  # Makes results easier to work with
    return conn
```

**3. Initialize database (create table):**
```python
def init_db():
    conn = get_db()
    conn.execute('''
        CREATE TABLE IF NOT EXISTS notes (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            text TEXT NOT NULL,
            created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
        )
    ''')
    conn.commit()
    conn.close()
```

**4. Update routes to use database:**
```python
@app.route('/')
def home():
    conn = get_db()
    notes = conn.execute('SELECT * FROM notes').fetchall()
    conn.close()
    return render_template('index.html', notes=notes)
```

## Sinatra Implementation

See `resources/sinatra-sqlite-example.rb` for complete, commented code.

**Key changes:**

**1. Require sqlite3:**
```ruby
require 'sqlite3'
```

**2. Create database connection:**
```ruby
DB = SQLite3::Database.new 'notes.db'
DB.results_as_hash = true
```

**3. Create table:**
```ruby
DB.execute <<-SQL
  CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
  )
SQL
```

**4. Update routes:**
```ruby
get '/' do
  @notes = DB.execute('SELECT * FROM notes')
  erb :index
end
```

## Teaching Approach

### Explain Each SQL Statement

**CREATE TABLE:**
```sql
CREATE TABLE IF NOT EXISTS notes (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    text TEXT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
)
```

**Explanation for beginners:**
```
- CREATE TABLE notes: Make a new table called "notes"
- IF NOT EXISTS: Only if it doesn't already exist (safe to run multiple times)
- id INTEGER PRIMARY KEY AUTOINCREMENT:
  - Unique number for each note
  - Automatically increments (1, 2, 3, ...)
  - PRIMARY KEY means it identifies each row
- text TEXT NOT NULL:
  - Column for note content
  - TEXT type (stores text/strings)
  - NOT NULL means it must have a value
- created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP:
  - When note was created
  - Automatically filled with current time
```

**INSERT:**
```sql
INSERT INTO notes (text) VALUES (?)
```

**Explanation:**
```
- INSERT INTO notes: Add data to notes table
- (text): We're providing the text column
- VALUES (?): The ? is a placeholder (safer than putting text directly)
- We pass actual text separately to prevent SQL injection
```

**SELECT:**
```sql
SELECT * FROM notes ORDER BY created_at DESC
```

**Explanation:**
```
- SELECT *: Get all columns
- FROM notes: From the notes table
- ORDER BY created_at DESC: Sort by creation time, newest first
  - ASC = ascending (oldest first)
  - DESC = descending (newest first)
```

## Common Questions

**Q: Where is the database file?**
A: In your project folder: `notes.db`. You can see it after running the app once.

**Q: Can I look inside the database?**
A: Yes! Tools like:
- DB Browser for SQLite (free, visual)
- sqlite3 command line
- VS Code extensions

**Q: What if I make a mistake?**
A: Just delete `notes.db` file. It will recreate on next run (but data is lost).

**Q: Do I need to install SQLite?**
A:
- Python: Built-in, no installation needed
- Ruby: Install gem: `gem install sqlite3`

**Q: Will my HTML template need changes?**
A: Minor changes - see examples for template adjustments

**Q: What about SQL injection?**
A: We use `?` placeholders (prepared statements) - this is safe. Never put user input directly in SQL!

## Testing the Database

**After adding SQLite:**

**Test 1: Add a note**
- Add note through form
- Restart server
- Check if note still there ✓

**Test 2: Check database file**
- Look in project folder
- `notes.db` file should exist
- Size should grow as you add notes

**Test 3: Multiple operations**
- Add several notes
- Restart server
- All notes should persist

**Test 4: Delete database file**
- Stop server
- Delete `notes.db`
- Start server
- New empty database created

## Migration Path

**Phase 1: Basic SQLite (start here)**
- Single table
- Simple queries
- No relationships

**Phase 2: Multiple tables (later)**
- Users and notes separately
- Foreign keys linking them

**Phase 3: More advanced (much later)**
- Complex queries
- JOIN operations
- Indexes for speed

**Phase 4: Production database (way later)**
- PostgreSQL or MySQL
- Same SQL concepts apply!

## Troubleshooting

**"sqlite3.OperationalError: no such table"**
- Table not created
- Run `init_db()` function
- Check if `CREATE TABLE` ran

**"Database is locked"**
- Another program has database open
- Close DB Browser or other tools
- Restart server

**"No such column"**
- Typo in column name
- Check exact spelling in SQL

**Template shows weird data format**
- Need to access dict/Row correctly
- See framework examples for proper syntax

## Complete Examples

Both complete, working examples with all teaching comments are in the resources folder:
- `resources/flask-sqlite-example.py`
- `resources/sinatra-sqlite-example.rb`
- `resources/sql-basics.md`

These include:
- Full commented code
- Template adjustments needed
- How to run and test
- What to expect at each step

## Next Steps After SQLite

Once comfortable with SQLite:
- Add UPDATE and DELETE operations
- Learn about relationships (foreign keys)
- Add search/filter functionality
- Explore indexes for speed
- Consider migration to PostgreSQL (production)
