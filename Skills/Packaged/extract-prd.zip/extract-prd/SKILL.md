---
name: extract-prd
description: Extract lifecycle artifacts from existing codebases
version: "0.34.1"
license: Complete terms in LICENSE.txt
---

# Skill: extract-prd

**Purpose:** Extract lifecycle artifacts from existing codebases
**Audience:** Developers documenting legacy or undocumented projects
**Load with:** Anti-Hallucination-Rules-for-PRD-Work.md

---

## Overview

The `extract-prd` skill analyzes existing codebases to generate lifecycle artifacts (CHARTER.md + Inception/ directory). It extracts features from tests, infers architecture from code patterns, and produces draft documentation for user refinement.

**Use Case:** You have working code but no charter or documentation. This skill reverse-engineers lifecycle artifacts from what was built.

**Critical:** All extracted content must be traceable to code evidence. Never invent details not supported by tests, code patterns, or documentation. Mark all inferences with confidence levels and flag for user validation.

**Output:** CHARTER.md + Inception/ artifacts (not PRD worksheets)

---

## When to Use

- Legacy codebase without documentation
- Project built without upfront requirements
- Onboarding to existing project
- Pre-LTS baseline documentation
- Session startup detects code but no charter

---

## Skill Commands

| Command | Purpose | Output |
|---------|---------|--------|
| `Analyze-Structure` | Map file/directory organization, detect tech stack | Inception/Architecture.md, Inception/Tech-Stack.md |
| `Extract-From-Tests` | Parse test files for feature descriptions | Inception/Scope-Boundaries.md |
| `Extract-From-API` | Parse API definitions for endpoints/operations | Inception/Scope-Boundaries.md |
| `Detect-NFRs` | Identify NFRs from code patterns | Inception/Constraints.md, Inception/Test-Strategy.md |
| `Generate-Artifacts` | Output CHARTER.md + Inception/ directory | Full lifecycle structure |

---

## Extraction Source Mapping

### Priority 1: High-Value Sources

| Source | Extracts To | Parsing Approach |
|--------|-------------|------------------|
| **Test files** | Inception/Scope-Boundaries.md, Inception/Test-Strategy.md | Test descriptions, assertions |
| **API routes** | Inception/Scope-Boundaries.md | Route definitions, handlers |
| **OpenAPI/Swagger** | Inception/Scope-Boundaries.md, Inception/Architecture.md | Schema parsing |
| **GraphQL schema** | Inception/Scope-Boundaries.md, Inception/Architecture.md | SDL parsing |
| **Source structure** | Inception/Architecture.md | Directory patterns, layer detection |

### Priority 2: Supporting Sources

| Source | Extracts To | Parsing Approach |
|--------|-------------|------------------|
| **README.md** | CHARTER.md, Inception/Charter-Details.md | Section extraction |
| **Config files** | Inception/Constraints.md | Pattern matching |
| **Package files** (package.json, go.mod, pyproject.toml, requirements.txt, Gemfile) | Inception/Tech-Stack.md | JSON/YAML/TOML parsing |
| **Dockerfile** | Inception/Architecture.md | Command analysis |

### Priority 3: Supplementary Sources

| Source | Extracts To | Parsing Approach |
|--------|-------------|------------------|
| **Git history** | Inception/Milestones.md | Commit message analysis |
| **Comments** | Inception/Charter-Details.md | Docstring extraction |
| **Error handlers** | Inception/Constraints.md | Exception patterns |
| **CI/CD files** | Transition/Deployment-Guide.md (draft) | Workflow parsing |

---

## Test Parsing Patterns

### Python (pytest)

```python
# Pattern: def test_[feature]_[behavior]():
def test_user_can_register_with_email():
    """User registration with email and password"""
    # → Scope: User Registration
    # → Behavior: User can register with email
```

**Extraction Rules:**
- Function name: `test_<feature>_<behavior>` → Feature + Behavior
- Docstring: Description text → Scope item description
- Assertions: `assert` statements → Scope boundaries

### JavaScript/TypeScript (Jest/Mocha)

```javascript
// Pattern: describe('[Feature]', () => { it('[behavior]', () => {}) })
describe('User Registration', () => {
  it('should allow registration with email and password', () => {
    // → Scope: User Registration
    // → Behavior: Registration with email and password
  });
});
```

**Extraction Rules:**
- `describe()` blocks → Feature grouping
- `it()` / `test()` → Individual behaviors
- Nested `describe()` → Feature hierarchy

### Ruby (RSpec)

```ruby
# Pattern: describe/context/it blocks
RSpec.describe 'User Registration' do
  context 'with valid email' do
    it 'creates a new user account' do
      # → Scope: User Registration
      # → Behavior: Creates account with valid email
    end
  end
end
```

### Java (JUnit)

```java
// Pattern: @Test with @DisplayName
@Test
@DisplayName("User can register with valid email")
void userCanRegisterWithValidEmail() {
    // → Scope: User Registration
    // → Behavior: Registration with valid email
}
```

---

## NFR Detection Patterns

### Security Patterns → Inception/Constraints.md

| Code Pattern | Inferred Constraint |
|--------------|---------------------|
| `bcrypt`, `argon2`, `scrypt` | Password hashing required |
| `@authenticate`, `requireAuth` | Authentication required |
| `@authorize`, `checkPermission` | Authorization controls |
| `csrf_token`, `csrfProtection` | CSRF protection |
| `validate`, `sanitize`, `escape` | Input validation required |
| `encrypt`, `decrypt`, `AES` | Data encryption required |
| `rateLimit`, `throttle` | Rate limiting configured |

### Performance Patterns → Inception/Constraints.md

| Code Pattern | Inferred Constraint |
|--------------|---------------------|
| `@cache`, `redis`, `memcached` | Caching implemented |
| `pool`, `connection pool` | Connection pooling required |
| `index`, `createIndex` | Database indexing strategy |
| `pagination`, `limit`, `offset` | Pagination support |

### Reliability Patterns → Inception/Constraints.md

| Code Pattern | Inferred Constraint |
|--------------|---------------------|
| `retry`, `maxRetries` | Retry logic implemented |
| `circuit`, `breaker` | Circuit breaker pattern |
| `timeout`, `deadline` | Timeout handling |
| `transaction`, `commit`, `rollback` | Transaction support |

### Test Patterns → Inception/Test-Strategy.md

| Code Pattern | Inferred Strategy |
|--------------|-------------------|
| `pytest`, `jest`, `rspec` | Test framework identified |
| `mock`, `stub`, `fake` | Mocking strategy |
| `coverage`, `nyc`, `istanbul` | Coverage requirements |
| `e2e`, `integration`, `unit` | Test level strategy |

---

## Architecture Inference → Inception/Architecture.md

### Application Type Detection

| Pattern | Inferred Architecture |
|---------|----------------------|
| `/api/*` routes, REST handlers | REST API |
| `schema.graphql`, resolvers | GraphQL API |
| `/pages/*`, `/app/*` (Next.js) | SSR Web Application |
| `index.html`, SPA routing | Single Page Application |
| `main()`, CLI args | Command Line Tool |
| `worker`, `queue`, `job` | Background Worker |
| `socket`, `websocket`, `ws` | Real-time Application |

### Framework Detection → Inception/Tech-Stack.md

| Files/Patterns | Framework |
|----------------|-----------|
| `package.json` + `express` | Express.js |
| `package.json` + `next` | Next.js |
| `requirements.txt` + `flask` | Flask |
| `requirements.txt` + `fastapi` | FastAPI |
| `pyproject.toml` + `flask` | Flask |
| `pyproject.toml` + `fastapi` | FastAPI |
| `pyproject.toml` + `django` | Django |
| `Gemfile` + `rails` | Ruby on Rails |
| `Gemfile` + `sinatra` | Sinatra |
| `pom.xml` + `spring` | Spring Boot |
| `go.mod` + `gin` | Gin (Go) |

### Database Detection → Inception/Tech-Stack.md

| Pattern | Database Type |
|---------|---------------|
| `sqlite`, `.db` file | SQLite |
| `postgres`, `pg` | PostgreSQL |
| `mysql`, `mariadb` | MySQL/MariaDB |
| `mongodb`, `mongoose` | MongoDB |
| `prisma`, `typeorm`, `sequelize` | ORM (various) |

---

## Artifact Generation

### CHARTER.md (Auto-populated)

```markdown
# Project Charter: {project-name}

**Status:** Draft (Extracted)
**Extraction Confidence:** {overall-confidence}

## Vision

{Extracted from README or inferred from package description}

## Current Focus

{Inferred from recent commits or marked as "Unknown - needs input"}

## Tech Stack

| Layer | Technology |
|-------|------------|
| Language | {detected} |
| Framework | {detected} |
| Database | {detected} |

## In Scope (Current)

- {Extracted feature 1}
- {Extracted feature 2}
- {Extracted feature 3}

---
*Extracted by extract-prd skill - Review and refine*
*See Inception/ for full specifications*
```

### Inception/Charter-Details.md (Auto-populated)

```markdown
# Project Charter Details: {project-name}

**Generated:** {date}
**Extraction Method:** Code Analysis
**Overall Confidence:** {High|Medium|Low}

---

## 1. Vision (Full)

### Problem Statement
{Extracted from README or "Needs input"}
**Confidence:** {level}

### Target Users
{Inferred from features or "Needs input"}
**Confidence:** {level}

### Value Proposition
{Extracted or "Needs input"}
**Confidence:** {level}

---

## 2. Scope (Full)

### In Scope (Extracted Features)

| Feature | Confidence | Evidence |
|---------|------------|----------|
| {Feature 1} | High | tests/test_feature1.py |
| {Feature 2} | Medium | README.md section |
| {Feature 3} | Low | Inferred from routes |

### Out of Scope
{Needs user input}

---

## 3. Technical Approach

### Technology Stack
{See Inception/Tech-Stack.md}

### Architecture Style
{Detected pattern} - **Confidence:** {level}

---

## Extraction Notes

| Section | Confidence | Action Required |
|---------|------------|-----------------|
| Vision | {level} | {Verify/Input needed} |
| Scope | {level} | {Verify/Input needed} |
| Technical | {level} | {Verify/Input needed} |

---

*Extracted by extract-prd skill*
```

### Inception/Tech-Stack.md (Auto-populated)

```markdown
# Tech Stack: {project-name}

**Extracted:** {date}

---

## Core Stack

| Layer | Technology | Version | Confidence |
|-------|------------|---------|------------|
| Language | {detected} | {version} | High |
| Runtime | {detected} | {version} | High |
| Framework | {detected} | {version} | High |
| Database | {detected} | {version} | Medium |

---

## Dependencies (Extracted)

| Package | Version | Purpose |
|---------|---------|---------|
| {dep1} | {version} | {inferred purpose} |
| {dep2} | {version} | {inferred purpose} |

---

*Extracted from package files*
```

### Inception/Scope-Boundaries.md (Auto-populated)

```markdown
# Scope Boundaries: {project-name}

**Extracted:** {date}

---

## In Scope (Extracted)

### Features (from tests)

| Feature | Evidence | Confidence |
|---------|----------|------------|
| {Feature 1} | {test file} | High |
| {Feature 2} | {test file} | High |

### API Endpoints (from routes)

| Endpoint | Method | Purpose | Confidence |
|----------|--------|---------|------------|
| {path} | {GET/POST} | {inferred} | Medium |

---

## Out of Scope

{Needs user input - cannot be extracted}

---

*Extracted by extract-prd skill*
```

---

## Confidence Levels

| Level | Criteria | User Action |
|-------|----------|-------------|
| **High** | Multiple sources confirm, explicit in tests | Verify only |
| **Medium** | Single source, reasonable inference | Review and confirm |
| **Low** | Indirect evidence, pattern-based guess | Validate carefully |

**Overall Confidence:** Lowest confidence of any critical section.

---

## Output Structure

### Generated Files

```
project-root/
├── CHARTER.md                      ← Overview (extracted)
│
├── Inception/                      ← What we're building
│   ├── Charter-Details.md          ← Full specs (extracted)
│   ├── Architecture.md             ← System view (extracted)
│   ├── Tech-Stack.md               ← Dependencies (extracted)
│   ├── Scope-Boundaries.md         ← Features (extracted)
│   ├── Test-Strategy.md            ← Test approach (extracted)
│   ├── Constraints.md              ← NFRs (extracted)
│   └── Milestones.md               ← Empty (needs input)
│
├── Construction/                   ← Empty (populated during dev)
│   ├── Test-Plans/
│   ├── Design-Decisions/
│   ├── Sprint-Retros/
│   └── Tech-Debt/
│
└── Transition/                     ← Empty (populated during release)
    ├── Deployment-Guide.md         ← Draft if CI/CD detected
    ├── Runbook.md
    └── User-Documentation.md
```

---

## Workflow Integration

### With Session Startup

```
Session Startup
    ↓
Check: CHARTER.md exists?
    ↓
[NO] → Check: Code exists?
    ↓
[YES] → Offer extraction mode
    ↓
User confirms → extract-prd executes
    ↓
Generate-Artifacts → Lifecycle structure
    ↓
User reviews → Edits as needed
    ↓
Commit artifacts
```

### With create-prd

Extraction provides foundation; create-prd builds on it:
- `extract-prd` → Inception/ from code
- `create-prd` → PRD from proposal + Inception/

---

## Limitations

1. **Cannot understand intent** - Only extracts what's explicit in code
2. **Missing context** - Business rationale not in code is not captured
3. **False positives** - Some patterns may be incorrectly interpreted
4. **Language coverage** - Best support for Python, JavaScript, Java, Ruby, Go
5. **Framework specifics** - May miss framework-specific patterns

**Important:** Extracted artifacts are **drafts** requiring human refinement.

---

## User Confirmation Flow

After extraction, present summary:

```
Extraction Complete!

Files generated:
  ✓ CHARTER.md (Medium confidence)
  ✓ Inception/Charter-Details.md
  ✓ Inception/Architecture.md (High confidence)
  ✓ Inception/Tech-Stack.md (High confidence)
  ✓ Inception/Scope-Boundaries.md (Medium confidence)
  ✓ Inception/Constraints.md
  ✓ Inception/Test-Strategy.md
  ⊘ Inception/Milestones.md (empty - needs input)
  ✓ Construction/ directories (empty)
  ✓ Transition/ directories (empty)

Items needing review:
  ! Vision statement (Low confidence)
  ! Out of scope items (not extractable)
  ! Milestones (needs input)

Review and edit now? (yes/no)
```

### Targeted Questions for Gaps

When user chooses to review, prompt for low-confidence/missing items:

| Gap Type | Targeted Question |
|----------|-------------------|
| Vision (Low) | "What problem does this project solve?" |
| Out of scope | "What should this project explicitly NOT do?" |
| Milestones | "What are the key milestones or phases planned?" |
| Target users | "Who are the primary users of this project?" |
| Constraints | "Any specific constraints (performance, security, compliance)?" |

**Questioning Rules:**
1. Only ask about items marked Low confidence or "needs input"
2. Present 2-3 questions at a time
3. Accept "skip" or "unknown" responses
4. Update artifacts with responses

---

**End of Skill**
